import hashlib, os

def calculate_sha256(filepath):
    sha256_hash = hashlib.sha256()
    with open(filepath, "rb") as f:
        for byte_block in iter(lambda: f.read(4096), b""):
            sha256_hash.update(byte_block)
    return sha256_hash.hexdigest()

def audit_file_corruption(original_path, s3_downloaded_path):
    orig_hash = calculate_sha256(original_path)
    s3_hash = calculate_sha256(s3_downloaded_path)
    
    orig_size = os.path.getsize(original_path)
    s3_size = os.path.getsize(s3_downloaded_path)
    
    print(f"Original File : {orig_size} bytes | SHA-256: {orig_hash}")
    print(f"S3 File       : {s3_size} bytes | SHA-256: {s3_hash}")
    
    if orig_hash == s3_hash:
        print("[UNICODE:2705] Integrity Verified: Files match exactly.")
    else:
        print("[UNICODE:274C] CORRUPTION DETECTED!")
        if orig_size != s3_size:
            print(f"   Delta: {s3_size - orig_size} bytes difference.")
