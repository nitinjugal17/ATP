# [CHART] Analytics Dashboard Performance Test Plan

**Target Environment**: `zerodha.com` (`https://zerodha.com`)  
**Objective**: Validate NFRs for rendering large datasets (10k-1M records).

---

## [UNICODE:1F30D] 1. Browser & Front-End Performance Strategy
*   **DOM Virtualization:** Use `react-window` so only visible rows (~20-50) exist in DOM.
*   **Lazy Loading:** Load heavy chart modules asynchronously.
*   **Server-Side Fetching:** Paginate or infinite scroll datasets > 1,000 items.

## [PLUG] 2. API & Database Optimization Strategy
*   **Indexing & Views:** Composite indexes or materialized views for time-series filters.
*   **Payload Compression:** Gzip/Brotli on REST/GraphQL array responses.

## [UNICODE:1F4CA] 3. Pass/Fail SLA Matrix
