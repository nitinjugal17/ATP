# Master Diagnostic Collector Configuration for Cloud Selenium Grid
import uuid, os
from selenium import webdriver

def get_cloud_grid_diagnostic_options(worker_id=0):
    opts = webdriver.ChromeOptions()
    opts.binary_location = "/usr/bin/chromium"
    opts.add_argument("--headless=new")
    opts.add_argument("--no-sandbox")
    opts.add_argument("--disable-dev-shm-usage")
    opts.add_argument("--disable-animations")
    
    # 1. Unique Browser Profile per Parallel Worker (Prevents State Collisions)
    profile_dir = os.path.abspath(f"artifacts/tmp/profile_worker_{worker_id}")
    opts.add_argument(f"--user-data-dir={profile_dir}")
    
    # 2. Dynamic Port Binding
    opts.add_argument("--remote-debugging-port=0")
    
    # 3. HAR & CDP Performance Logging Capabilities
    opts.set_capability("goog:loggingPrefs", {"performance": "ALL", "browser": "ALL"})
    
    return opts
