# [UNICODE:1F6E1] Defensive Input Validation & Security Regression Strategy

**Target Environment**: `zerodha.com` (`https://zerodha.com`)  
**Note**: This report outlines defensive QA regression strategies. Actual exploitation payloads are excluded by policy.

---


*   **Root Cause:** Dynamically concatenating user-supplied input into database queries.
*   **Defensive Mitigation:** Parameterized Queries (Prepared Statements).
*   **QA Verification:** Test boundary conditions (exceeding length, special characters `';%00`). Verify standard HTTP 400 validation errors rather than HTTP 500 DB syntax crashes.

*   **Root Cause:** Untrusted user input rendered in DOM without context-aware encoding.
*   **Defensive Mitigation:** Contextual Output Encoding (React/Angular auto-escaping) and strict Content Security Policy (CSP).
*   **QA Verification:** Input safe HTML-like strings (`<b>test</b>`). Confirm rendered output is encoded (`&lt;b&gt;`) and does not execute.

*   **Root Cause:** Passing unsanitized input to system shell execution.
*   **Defensive Mitigation:** Avoid shell invocations (`execFile` instead of `exec`), strict allowlisting.
*   **QA Verification:** Pass filenames with spaces/paths (`../`). Verify rejection by validation schemas (e.g., Zod) before backend processing.

*   **Root Cause:** Deserializing untrusted object streams.
*   **Defensive Mitigation:** Safe Data Interchange Formats (JSON `JSON.parse()`).
*   **QA Verification:** Submit malformed JSON types. Confirm parser rejects with HTTP 400 without crashing process.
