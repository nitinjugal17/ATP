import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

@pytest.fixture
def driver():
    driver = webdriver.Chrome()
    yield driver
    driver.quit()

def test_landing_page(driver):
    driver.get("https://zerodha.com/")
    
    # Verify the page title
    assert driver.title == "Zerodha: Online brokerage platform for stock trading & investing"
    
    # Verify the presence of the main heading element
    heading = driver.find_element(By.TAG_NAME, "h1")
    assert heading.is_displayed(), "Main heading element is not visible"
    
    # Additional assertions can be added here to verify other elements and functionalities
