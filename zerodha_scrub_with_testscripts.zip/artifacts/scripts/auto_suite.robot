*** Settings ***
Documentation     Master Orchestration Suite Grounded by Enterprise RAG.
...               Target Application: https://zerodha.com
Library    keywords_lib.SUTKeywords    WITH NAME    SUT

# --- MANDATORY LIFECYCLE HOOKS ---
Suite Setup       SUT.Start Browser
Suite Teardown    SUT.Stop Browser
Test Setup        Log    Initializing Test Data and resetting DOM state for isolated execution.
Test Teardown     Run Keyword If Test Failed    SUT.Take Screenshot    ${TEST NAME}_failure.png

*** Variables ***
${URL}              ${BASE_URL}
${BASE_URL}         https://zerodha.com
${VALID_USER}       admin
${VALID_PASS}       password123
${API_ENDPOINT}     https://zerodha.com/api/v1/health

*** Test Cases ***

# ============================# CATEGORY 0: SENIOR MANUAL QA MULTI-STEP USER JOURNEYS
# ============================
TC-JOURNEY-01: End-to-End User Discovery, Navigation & Brand Layout Flow :: Full multi-step landing exploration
    [Documentation]    [ASPICE Trace: REQ:BRD-JOURNEY-01 | Priority: Critical]
    ...                Business Objective: Execute end-to-end user traversal from landing to brand hero and links.
    ...                Acceptance Criteria: Landing loads within SLA, header renders, and primary links are verified.
    [Tags]    Manual-QA-Journey    E2E    Smoke    Critical
    Given the user sets viewport resolution    1920    1080
    And the user navigates to sub-route    https://zerodha.com
    When the page DOM content and interactive elements load
    Then the destination URL should be reachable    https://zerodha.com
    And the page title should not be empty
    And the heading element should be visible    css=h1, h2, h3
    And the primary structural sections should be visible
    And the page state should remain stable and error-free

TC-JOURNEY-02: Form Interaction, Boundary Limits & Data Integrity Flow :: Tests field boundary lifecycle
    [Documentation]    [ASPICE Trace: REQ:BRD-JOURNEY-02 | Priority: High]
    ...                Business Objective: Validate form data entry lifecycle, empty state rejection, and safe boundaries.
    ...                Acceptance Criteria: Input handles boundary strings gracefully without unhandled exceptions.
    [Tags]    Manual-QA-Journey    Form-Lifecycle    Validation    High
    Given the user navigates to sub-route    https://zerodha.com
    When the page DOM content and interactive elements load
    Then the page state should remain stable and error-free

TC-JOURNEY-03: UI State Mutation, Interactive Controls & Component Resilience Flow :: Exercises buttons and toggles
    [Documentation]    [ASPICE Trace: REQ:BRD-JOURNEY-03 | Priority: High]
    ...                Business Objective: Validate interactive controls, double-click idempotency, and DOM stability.
    ...                Acceptance Criteria: UI responds to clicks with pointer cursors and no layout breaks.
    [Tags]    Manual-QA-Journey    Interactivity    Resilience    High
    Given the user navigates to sub-route    https://zerodha.com
    When the page DOM content and interactive elements load
    Then the page state should remain stable and error-free

TC-JOURNEY-04: Security Shielding, Safe Negative Injection & Error Recovery Flow :: Validates defensive boundary
    [Documentation]    [ASPICE Trace: REQ:BRD-JOURNEY-04 | Priority: Critical]
    ...                Business Objective: Ensure application shields against malformed inputs and prevents raw stack traces.
    ...                Acceptance Criteria: Zero 500 error leakages or script execution vulnerabilities.
    [Tags]    Manual-QA-Journey    Security    Negative-Testing    Critical
    Given the user navigates to sub-route    https://zerodha.com
    When the page DOM content and interactive elements load
    Then no unhandled server error should be exposed
    And no debug stack traces should be visible

TC-JOURNEY-05: Core Web Vitals, Rendering Latency SLA & Asset Integrity Flow :: Validates performance SLA
    [Documentation]    [ASPICE Trace: REQ:BRD-JOURNEY-05 | Priority: Medium]
    ...                Business Objective: Verify page rendering latency is within enterprise SLA threshold (< 5.0s).
    ...                Acceptance Criteria: DOM readiness achieved within SLA and localization meta tags verified.
    [Tags]    Manual-QA-Journey    Performance    CoreWebVitals    Medium
    Given the user navigates to sub-route    https://zerodha.com
    When the client performance metrics are evaluated
    Then the page render speed must be under the SLA threshold
    And the page layout should remain intact after scrolling

# ============================# CATEGORY 1: RAG CONTEXTUAL WORKFLOWS (10 PER PAGE)
# ============================
TC-P01-01-NAV: Verify Route Reachability, SEO Document Title & Header Layout on [Landing_General]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE01-NAV | Priority: Critical]
    ...                Business Objective: Verify Route Reachability, SEO Document Title & Header Layout on [Landing_General]
    ...                Acceptance Criteria: Page Landing_General loads with HTTP 200 state, non-empty document title, and verified header layout.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE01-NAV    Critical
    Given the user sets viewport resolution    1920    1080
    And the user navigates to sub-route    https://zerodha.com/
    When the page DOM content and interactive elements load
    Then the destination URL should be reachable    https://zerodha.com/
    And the page title should not be empty
    And the heading element should be visible    css=h1, h2, h3
TC-P01-01.5-FWK: Verify Modern Web Framework Integrity (React/Angular/Vue/Shadow DOM) & Zero Crash State on [Landing_General]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE01-FWK | Priority: Critical]
    ...                Business Objective: Verify Modern Web Framework Integrity (React/Angular/Vue/Shadow DOM) & Zero Crash State on [Landing_General]
    ...                Acceptance Criteria: Framework runtime on Landing_General is stable with zero hydration mismatch, unhandled promise rejections, or React/Vue error boundary crashes.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE01-FWK    Critical
    Given the user navigates to sub-route    https://zerodha.com/
    When the client performance metrics are evaluated
    Then the page state should remain stable and error-free
    And no unhandled server error should be exposed
    And no debug stack traces should be visible
TC-P01-02-SEC: Verify Structural Sections, Container Hierarchy & Copy on [Landing_General]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE01-SEC | Priority: High]
    ...                Business Objective: Verify Structural Sections, Container Hierarchy & Copy on [Landing_General]
    ...                Acceptance Criteria: All structural containers render with correct visual hierarchy and matching copy.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE01-SEC    High
    Given the user navigates to sub-route    https://zerodha.com/
    When the page layout structure and section containers are inspected
    Then the primary structural sections should be visible
    And the page state should remain stable and error-free
TC-P01-03-IMG: Verify Visual Image Asset [BRAND_LOGO] Rendering & WCAG 1.1.1 Alt Text on [Landing_General]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE01-IMG | Priority: High]
    ...                Business Objective: Verify Visual Image Asset [BRAND_LOGO] Rendering & WCAG 1.1.1 Alt Text on [Landing_General]
    ...                Acceptance Criteria: Image css=img[alt='Zerodha logo'] (BRAND_LOGO) loads successfully and complies with WCAG 1.1.1.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE01-IMG    High
    Given the user navigates to sub-route    https://zerodha.com/
    When the image element is inspected    css=img[alt='Zerodha logo']
    Then the image asset should return HTTP 200 state
    And the image should satisfy WCAG 1.1.1 with text alternative: 'Zerodha logo'
    And the image should render without broken layout dimensions
TC-P01-08-SEC: Verify Defensive Security Isolation & Absence of Error Leaks on [Landing_General]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE01-SEC | Priority: Critical]
    ...                Business Objective: Verify Defensive Security Isolation & Absence of Error Leaks on [Landing_General]
    ...                Acceptance Criteria: Zero unhandled exceptions or sensitive debug stack traces exposed.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE01-SEC    Critical
    Given the user navigates to sub-route    https://zerodha.com/
    When the page DOM content and interactive elements load
    Then no unhandled server error should be exposed
    And no debug stack traces should be visible
TC-P01-11-CONCUR: Verify Simultaneous Peak Concurrency (At Same Time) Resilience on [Landing_General]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE01-CONCUR | Priority: Critical]
    ...                Business Objective: Verify Simultaneous Peak Concurrency (At Same Time) Resilience on [Landing_General]
    ...                Acceptance Criteria: System withstands simultaneous concurrent burst traffic without degradation or socket exhaustion.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE01-CONCUR    Critical
    Given a concurrent user pool of 20 virtual users
    When all virtual users launch sub-route at the exact same time    https://zerodha.com/
    Then the server must maintain HTTP 200 response rate above 95%
    And the response duration p(95) must remain under 3500ms SLA
    And no connection dropouts or 5xx server errors should occur
TC-P01-12-REPEAT: Verify Repeated Page Launches (Multiple Times) & TTFB Drift Consistency on [Landing_General]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE01-REPEAT | Priority: High]
    ...                Business Objective: Verify Repeated Page Launches (Multiple Times) & TTFB Drift Consistency on [Landing_General]
    ...                Acceptance Criteria: Repeated page launches exhibit consistent latency and zero server-side memory leaks.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE01-REPEAT    High
    Given an automated iteration harness configured for 10 consecutive cycles
    When the page is repeatedly loaded multiple times    https://zerodha.com/
    Then the Time-To-First-Byte (TTFB) must remain consistent (< 1200ms)
    And client-side caching headers must be respected
    And memory allocation must stabilize without cumulative latency drift
TC-P02-01-NAV: Verify Route Reachability, SEO Document Title & Header Layout on [Page_open_account]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE02-NAV | Priority: Critical]
    ...                Business Objective: Verify Route Reachability, SEO Document Title & Header Layout on [Page_open_account]
    ...                Acceptance Criteria: Page Page_open_account loads with HTTP 200 state, non-empty document title, and verified header layout.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE02-NAV    Critical
    Given the user sets viewport resolution    1920    1080
    And the user navigates to sub-route    https://zerodha.com/open-account/
    When the page DOM content and interactive elements load
    Then the destination URL should be reachable    https://zerodha.com/open-account/
    And the page title should not be empty
    And the heading element should be visible    css=h1, h2, h3
TC-P02-01.5-FWK: Verify Modern Web Framework Integrity (React/Angular/Vue/Shadow DOM) & Zero Crash State on [Page_open_account]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE02-FWK | Priority: Critical]
    ...                Business Objective: Verify Modern Web Framework Integrity (React/Angular/Vue/Shadow DOM) & Zero Crash State on [Page_open_account]
    ...                Acceptance Criteria: Framework runtime on Page_open_account is stable with zero hydration mismatch, unhandled promise rejections, or React/Vue error boundary crashes.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE02-FWK    Critical
    Given the user navigates to sub-route    https://zerodha.com/open-account/
    When the client performance metrics are evaluated
    Then the page state should remain stable and error-free
    And no unhandled server error should be exposed
    And no debug stack traces should be visible
TC-P02-02-HERO: Verify Hero Headline [Open a free demat and tra] and Primary CTA on [Page_open_account]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE02-HERO | Priority: High]
    ...                Business Objective: Verify Hero Headline [Open a free demat and tra] and Primary CTA on [Page_open_account]
    ...                Acceptance Criteria: Hero section renders headline 'Open a free demat and trading ' and CTA buttons cleanly.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE02-HERO    High
    Given the user navigates to sub-route    https://zerodha.com/open-account/
    When the hero section is inspected
    Then the hero headline should be visible with text    Open a free demat and trading account on
    And the page state should remain stable and error-free
TC-P02-03-IMG: Verify Visual Image Asset [BRAND_LOGO] Rendering & WCAG 1.1.1 Alt Text on [Page_open_account]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE02-IMG | Priority: High]
    ...                Business Objective: Verify Visual Image Asset [BRAND_LOGO] Rendering & WCAG 1.1.1 Alt Text on [Page_open_account]
    ...                Acceptance Criteria: Image css=img[alt='Zerodha logo'] (BRAND_LOGO) loads successfully and complies with WCAG 1.1.1.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE02-IMG    High
    Given the user navigates to sub-route    https://zerodha.com/open-account/
    When the image element is inspected    css=img[alt='Zerodha logo']
    Then the image asset should return HTTP 200 state
    And the image should satisfy WCAG 1.1.1 with text alternative: 'Zerodha logo'
    And the image should render without broken layout dimensions
TC-P02-04-BTN: Verify Action Button [Get OTP] Clickability & State Reaction on [Page_open_account]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE02-BTN | Priority: Critical]
    ...                Business Objective: Verify Action Button [Get OTP] Clickability & State Reaction on [Page_open_account]
    ...                Acceptance Criteria: Button is enabled, exhibits pointer cursor, and triggers response event without unhandled exceptions.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE02-BTN    Critical
    Given the user navigates to sub-route    https://zerodha.com/open-account/
    And the interactive element should be enabled    css=\#open_account_proceed_form
    When the user clicks the button with selector    css=\#open_account_proceed_form
    And the page network state stabilizes
    Then the post-action DOM state should reflect the user event    css=\#open_account_proceed_form
    And no unhandled server error should be exposed
TC-P02-05-FORM: Verify Form Input [mobile] Constraints, Nominal Data Entry & Value Persistence on [Page_open_account]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE02-FORM | Priority: Critical]
    ...                Business Objective: Verify Form Input [mobile] Constraints, Nominal Data Entry & Value Persistence on [Page_open_account]
    ...                Acceptance Criteria: Input field respects HTML5 constraints, accepts nominal data, and persists the entered value in the DOM.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE02-FORM    Critical
    Given the user navigates to sub-route    https://zerodha.com/open-account/
    When the user verifies input constraints    css=\#user_mobile    number
    And the user enters text into input field    css=\#user_mobile    Enterprise QA Verification
    Then the input field should retain value    css=\#user_mobile    Enterprise QA Verification
    And the page state should remain stable and error-free
TC-P02-06-BVA: Verify Boundary Constraint Validation (Empty/Whitespace/Overlength) on [Page_open_account]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE02-BVA | Priority: High]
    ...                Business Objective: Verify Boundary Constraint Validation (Empty/Whitespace/Overlength) on [Page_open_account]
    ...                Acceptance Criteria: System handles boundary whitespace, length boundaries, and empty submissions with inline validation, zero 500 crashes.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE02-BVA    High
    Given the user navigates to sub-route    https://zerodha.com/open-account/
    When boundary test inputs or empty submissions are executed on    css=\#user_mobile
    Then the page should handle validation gracefully without fatal errors
    And no unhandled server error should be exposed
TC-P02-08-SEC: Verify Defensive Security Isolation & Absence of Error Leaks on [Page_open_account]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE02-SEC | Priority: Critical]
    ...                Business Objective: Verify Defensive Security Isolation & Absence of Error Leaks on [Page_open_account]
    ...                Acceptance Criteria: Zero unhandled exceptions or sensitive debug stack traces exposed.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE02-SEC    Critical
    Given the user navigates to sub-route    https://zerodha.com/open-account/
    When the page DOM content and interactive elements load
    Then no unhandled server error should be exposed
    And no debug stack traces should be visible
TC-P02-11-CONCUR: Verify Simultaneous Peak Concurrency (At Same Time) Resilience on [Page_open_account]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE02-CONCUR | Priority: Critical]
    ...                Business Objective: Verify Simultaneous Peak Concurrency (At Same Time) Resilience on [Page_open_account]
    ...                Acceptance Criteria: System withstands simultaneous concurrent burst traffic without degradation or socket exhaustion.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE02-CONCUR    Critical
    Given a concurrent user pool of 20 virtual users
    When all virtual users launch sub-route at the exact same time    https://zerodha.com/open-account/
    Then the server must maintain HTTP 200 response rate above 95%
    And the response duration p(95) must remain under 3500ms SLA
    And no connection dropouts or 5xx server errors should occur
TC-P02-12-REPEAT: Verify Repeated Page Launches (Multiple Times) & TTFB Drift Consistency on [Page_open_account]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE02-REPEAT | Priority: High]
    ...                Business Objective: Verify Repeated Page Launches (Multiple Times) & TTFB Drift Consistency on [Page_open_account]
    ...                Acceptance Criteria: Repeated page launches exhibit consistent latency and zero server-side memory leaks.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE02-REPEAT    High
    Given an automated iteration harness configured for 10 consecutive cycles
    When the page is repeatedly loaded multiple times    https://zerodha.com/open-account/
    Then the Time-To-First-Byte (TTFB) must remain consistent (< 1200ms)
    And client-side caching headers must be respected
    And memory allocation must stabilize without cumulative latency drift
TC-P03-01-NAV: Verify Route Reachability, SEO Document Title & Header Layout on [Page_about]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE03-NAV | Priority: Critical]
    ...                Business Objective: Verify Route Reachability, SEO Document Title & Header Layout on [Page_about]
    ...                Acceptance Criteria: Page Page_about loads with HTTP 200 state, non-empty document title, and verified header layout.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE03-NAV    Critical
    Given the user sets viewport resolution    1920    1080
    And the user navigates to sub-route    https://zerodha.com/about/
    When the page DOM content and interactive elements load
    Then the destination URL should be reachable    https://zerodha.com/about/
    And the page title should not be empty
    And the heading element should be visible    css=h1, h2, h3
TC-P03-01.5-FWK: Verify Modern Web Framework Integrity (React/Angular/Vue/Shadow DOM) & Zero Crash State on [Page_about]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE03-FWK | Priority: Critical]
    ...                Business Objective: Verify Modern Web Framework Integrity (React/Angular/Vue/Shadow DOM) & Zero Crash State on [Page_about]
    ...                Acceptance Criteria: Framework runtime on Page_about is stable with zero hydration mismatch, unhandled promise rejections, or React/Vue error boundary crashes.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE03-FWK    Critical
    Given the user navigates to sub-route    https://zerodha.com/about/
    When the client performance metrics are evaluated
    Then the page state should remain stable and error-free
    And no unhandled server error should be exposed
    And no debug stack traces should be visible
TC-P03-02-FEAT: Verify Feature Card [Feature Block] Presentation & Copy on [Page_about]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE03-FEAT | Priority: High]
    ...                Business Objective: Verify Feature Card [Feature Block] Presentation & Copy on [Page_about]
    ...                Acceptance Criteria: Feature block renders with valid copy and responsive grid layout.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE03-FEAT    High
    Given the user navigates to sub-route    https://zerodha.com/about/
    When the feature cards are inspected
    Then the feature block should contain title    Feature Block
    And the page state should remain stable and error-free
TC-P03-03-IMG: Verify Visual Image Asset [BRAND_LOGO] Rendering & WCAG 1.1.1 Alt Text on [Page_about]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE03-IMG | Priority: High]
    ...                Business Objective: Verify Visual Image Asset [BRAND_LOGO] Rendering & WCAG 1.1.1 Alt Text on [Page_about]
    ...                Acceptance Criteria: Image css=img[alt='Zerodha logo'] (BRAND_LOGO) loads successfully and complies with WCAG 1.1.1.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE03-IMG    High
    Given the user navigates to sub-route    https://zerodha.com/about/
    When the image element is inspected    css=img[alt='Zerodha logo']
    Then the image asset should return HTTP 200 state
    And the image should satisfy WCAG 1.1.1 with text alternative: 'Zerodha logo'
    And the image should render without broken layout dimensions
TC-P03-08-SEC: Verify Defensive Security Isolation & Absence of Error Leaks on [Page_about]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE03-SEC | Priority: Critical]
    ...                Business Objective: Verify Defensive Security Isolation & Absence of Error Leaks on [Page_about]
    ...                Acceptance Criteria: Zero unhandled exceptions or sensitive debug stack traces exposed.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE03-SEC    Critical
    Given the user navigates to sub-route    https://zerodha.com/about/
    When the page DOM content and interactive elements load
    Then no unhandled server error should be exposed
    And no debug stack traces should be visible
TC-P03-11-CONCUR: Verify Simultaneous Peak Concurrency (At Same Time) Resilience on [Page_about]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE03-CONCUR | Priority: Critical]
    ...                Business Objective: Verify Simultaneous Peak Concurrency (At Same Time) Resilience on [Page_about]
    ...                Acceptance Criteria: System withstands simultaneous concurrent burst traffic without degradation or socket exhaustion.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE03-CONCUR    Critical
    Given a concurrent user pool of 20 virtual users
    When all virtual users launch sub-route at the exact same time    https://zerodha.com/about/
    Then the server must maintain HTTP 200 response rate above 95%
    And the response duration p(95) must remain under 3500ms SLA
    And no connection dropouts or 5xx server errors should occur
TC-P03-12-REPEAT: Verify Repeated Page Launches (Multiple Times) & TTFB Drift Consistency on [Page_about]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE03-REPEAT | Priority: High]
    ...                Business Objective: Verify Repeated Page Launches (Multiple Times) & TTFB Drift Consistency on [Page_about]
    ...                Acceptance Criteria: Repeated page launches exhibit consistent latency and zero server-side memory leaks.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE03-REPEAT    High
    Given an automated iteration harness configured for 10 consecutive cycles
    When the page is repeatedly loaded multiple times    https://zerodha.com/about/
    Then the Time-To-First-Byte (TTFB) must remain consistent (< 1200ms)
    And client-side caching headers must be respected
    And memory allocation must stabilize without cumulative latency drift
TC-P04-01-NAV: Verify Route Reachability, SEO Document Title & Header Layout on [Page_products]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE04-NAV | Priority: Critical]
    ...                Business Objective: Verify Route Reachability, SEO Document Title & Header Layout on [Page_products]
    ...                Acceptance Criteria: Page Page_products loads with HTTP 200 state, non-empty document title, and verified header layout.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE04-NAV    Critical
    Given the user sets viewport resolution    1920    1080
    And the user navigates to sub-route    https://zerodha.com/products/
    When the page DOM content and interactive elements load
    Then the destination URL should be reachable    https://zerodha.com/products/
    And the page title should not be empty
    And the heading element should be visible    css=h1, h2, h3
TC-P04-01.5-FWK: Verify Modern Web Framework Integrity (React/Angular/Vue/Shadow DOM) & Zero Crash State on [Page_products]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE04-FWK | Priority: Critical]
    ...                Business Objective: Verify Modern Web Framework Integrity (React/Angular/Vue/Shadow DOM) & Zero Crash State on [Page_products]
    ...                Acceptance Criteria: Framework runtime on Page_products is stable with zero hydration mismatch, unhandled promise rejections, or React/Vue error boundary crashes.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE04-FWK    Critical
    Given the user navigates to sub-route    https://zerodha.com/products/
    When the client performance metrics are evaluated
    Then the page state should remain stable and error-free
    And no unhandled server error should be exposed
    And no debug stack traces should be visible
TC-P04-02-SEC: Verify Structural Sections, Container Hierarchy & Copy on [Page_products]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE04-SEC | Priority: High]
    ...                Business Objective: Verify Structural Sections, Container Hierarchy & Copy on [Page_products]
    ...                Acceptance Criteria: All structural containers render with correct visual hierarchy and matching copy.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE04-SEC    High
    Given the user navigates to sub-route    https://zerodha.com/products/
    When the page layout structure and section containers are inspected
    Then the primary structural sections should be visible
    And the page state should remain stable and error-free
TC-P04-03-IMG: Verify Visual Image Asset [BRAND_LOGO] Rendering & WCAG 1.1.1 Alt Text on [Page_products]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE04-IMG | Priority: High]
    ...                Business Objective: Verify Visual Image Asset [BRAND_LOGO] Rendering & WCAG 1.1.1 Alt Text on [Page_products]
    ...                Acceptance Criteria: Image css=img[alt='Zerodha logo'] (BRAND_LOGO) loads successfully and complies with WCAG 1.1.1.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE04-IMG    High
    Given the user navigates to sub-route    https://zerodha.com/products/
    When the image element is inspected    css=img[alt='Zerodha logo']
    Then the image asset should return HTTP 200 state
    And the image should satisfy WCAG 1.1.1 with text alternative: 'Zerodha logo'
    And the image should render without broken layout dimensions
TC-P04-08-SEC: Verify Defensive Security Isolation & Absence of Error Leaks on [Page_products]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE04-SEC | Priority: Critical]
    ...                Business Objective: Verify Defensive Security Isolation & Absence of Error Leaks on [Page_products]
    ...                Acceptance Criteria: Zero unhandled exceptions or sensitive debug stack traces exposed.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE04-SEC    Critical
    Given the user navigates to sub-route    https://zerodha.com/products/
    When the page DOM content and interactive elements load
    Then no unhandled server error should be exposed
    And no debug stack traces should be visible
TC-P04-11-CONCUR: Verify Simultaneous Peak Concurrency (At Same Time) Resilience on [Page_products]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE04-CONCUR | Priority: Critical]
    ...                Business Objective: Verify Simultaneous Peak Concurrency (At Same Time) Resilience on [Page_products]
    ...                Acceptance Criteria: System withstands simultaneous concurrent burst traffic without degradation or socket exhaustion.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE04-CONCUR    Critical
    Given a concurrent user pool of 20 virtual users
    When all virtual users launch sub-route at the exact same time    https://zerodha.com/products/
    Then the server must maintain HTTP 200 response rate above 95%
    And the response duration p(95) must remain under 3500ms SLA
    And no connection dropouts or 5xx server errors should occur
TC-P04-12-REPEAT: Verify Repeated Page Launches (Multiple Times) & TTFB Drift Consistency on [Page_products]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE04-REPEAT | Priority: High]
    ...                Business Objective: Verify Repeated Page Launches (Multiple Times) & TTFB Drift Consistency on [Page_products]
    ...                Acceptance Criteria: Repeated page launches exhibit consistent latency and zero server-side memory leaks.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE04-REPEAT    High
    Given an automated iteration harness configured for 10 consecutive cycles
    When the page is repeatedly loaded multiple times    https://zerodha.com/products/
    Then the Time-To-First-Byte (TTFB) must remain consistent (< 1200ms)
    And client-side caching headers must be respected
    And memory allocation must stabilize without cumulative latency drift
TC-P05-01-NAV: Verify Route Reachability, SEO Document Title & Header Layout on [Page_pricing]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE05-NAV | Priority: Critical]
    ...                Business Objective: Verify Route Reachability, SEO Document Title & Header Layout on [Page_pricing]
    ...                Acceptance Criteria: Page Page_pricing loads with HTTP 200 state, non-empty document title, and verified header layout.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE05-NAV    Critical
    Given the user sets viewport resolution    1920    1080
    And the user navigates to sub-route    https://zerodha.com/pricing/
    When the page DOM content and interactive elements load
    Then the destination URL should be reachable    https://zerodha.com/pricing/
    And the page title should not be empty
    And the heading element should be visible    css=h1, h2, h3
TC-P05-01.5-FWK: Verify Modern Web Framework Integrity (React/Angular/Vue/Shadow DOM) & Zero Crash State on [Page_pricing]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE05-FWK | Priority: Critical]
    ...                Business Objective: Verify Modern Web Framework Integrity (React/Angular/Vue/Shadow DOM) & Zero Crash State on [Page_pricing]
    ...                Acceptance Criteria: Framework runtime on Page_pricing is stable with zero hydration mismatch, unhandled promise rejections, or React/Vue error boundary crashes.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE05-FWK    Critical
    Given the user navigates to sub-route    https://zerodha.com/pricing/
    When the client performance metrics are evaluated
    Then the page state should remain stable and error-free
    And no unhandled server error should be exposed
    And no debug stack traces should be visible
TC-P05-02-SEC: Verify Structural Sections, Container Hierarchy & Copy on [Page_pricing]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE05-SEC | Priority: High]
    ...                Business Objective: Verify Structural Sections, Container Hierarchy & Copy on [Page_pricing]
    ...                Acceptance Criteria: All structural containers render with correct visual hierarchy and matching copy.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE05-SEC    High
    Given the user navigates to sub-route    https://zerodha.com/pricing/
    When the page layout structure and section containers are inspected
    Then the primary structural sections should be visible
    And the page state should remain stable and error-free
TC-P05-03-IMG: Verify Visual Image Asset [BRAND_LOGO] Rendering & WCAG 1.1.1 Alt Text on [Page_pricing]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE05-IMG | Priority: High]
    ...                Business Objective: Verify Visual Image Asset [BRAND_LOGO] Rendering & WCAG 1.1.1 Alt Text on [Page_pricing]
    ...                Acceptance Criteria: Image css=img[alt='Zerodha logo'] (BRAND_LOGO) loads successfully and complies with WCAG 1.1.1.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE05-IMG    High
    Given the user navigates to sub-route    https://zerodha.com/pricing/
    When the image element is inspected    css=img[alt='Zerodha logo']
    Then the image asset should return HTTP 200 state
    And the image should satisfy WCAG 1.1.1 with text alternative: 'Zerodha logo'
    And the image should render without broken layout dimensions
TC-P05-08-SEC: Verify Defensive Security Isolation & Absence of Error Leaks on [Page_pricing]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE05-SEC | Priority: Critical]
    ...                Business Objective: Verify Defensive Security Isolation & Absence of Error Leaks on [Page_pricing]
    ...                Acceptance Criteria: Zero unhandled exceptions or sensitive debug stack traces exposed.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE05-SEC    Critical
    Given the user navigates to sub-route    https://zerodha.com/pricing/
    When the page DOM content and interactive elements load
    Then no unhandled server error should be exposed
    And no debug stack traces should be visible
TC-P05-11-CONCUR: Verify Simultaneous Peak Concurrency (At Same Time) Resilience on [Page_pricing]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE05-CONCUR | Priority: Critical]
    ...                Business Objective: Verify Simultaneous Peak Concurrency (At Same Time) Resilience on [Page_pricing]
    ...                Acceptance Criteria: System withstands simultaneous concurrent burst traffic without degradation or socket exhaustion.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE05-CONCUR    Critical
    Given a concurrent user pool of 20 virtual users
    When all virtual users launch sub-route at the exact same time    https://zerodha.com/pricing/
    Then the server must maintain HTTP 200 response rate above 95%
    And the response duration p(95) must remain under 3500ms SLA
    And no connection dropouts or 5xx server errors should occur
TC-P05-12-REPEAT: Verify Repeated Page Launches (Multiple Times) & TTFB Drift Consistency on [Page_pricing]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE05-REPEAT | Priority: High]
    ...                Business Objective: Verify Repeated Page Launches (Multiple Times) & TTFB Drift Consistency on [Page_pricing]
    ...                Acceptance Criteria: Repeated page launches exhibit consistent latency and zero server-side memory leaks.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE05-REPEAT    High
    Given an automated iteration harness configured for 10 consecutive cycles
    When the page is repeatedly loaded multiple times    https://zerodha.com/pricing/
    Then the Time-To-First-Byte (TTFB) must remain consistent (< 1200ms)
    And client-side caching headers must be respected
    And memory allocation must stabilize without cumulative latency drift
TC-P06-01-NAV: Verify Route Reachability, SEO Document Title & Header Layout on [Landing_Auth]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE06-NAV | Priority: Critical]
    ...                Business Objective: Verify Route Reachability, SEO Document Title & Header Layout on [Landing_Auth]
    ...                Acceptance Criteria: Page Landing_Auth loads with HTTP 200 state, non-empty document title, and verified header layout.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE06-NAV    Critical
    Given the user sets viewport resolution    1920    1080
    And the user navigates to sub-route    https://kite.zerodha.com
    When the page DOM content and interactive elements load
    Then the destination URL should be reachable    https://kite.zerodha.com
    And the page title should not be empty
    And the heading element should be visible    css=h1, h2, h3
TC-P06-01.5-FWK: Verify Modern Web Framework Integrity (React/Angular/Vue/Shadow DOM) & Zero Crash State on [Landing_Auth]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE06-FWK | Priority: Critical]
    ...                Business Objective: Verify Modern Web Framework Integrity (React/Angular/Vue/Shadow DOM) & Zero Crash State on [Landing_Auth]
    ...                Acceptance Criteria: Framework runtime on Landing_Auth is stable with zero hydration mismatch, unhandled promise rejections, or React/Vue error boundary crashes.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE06-FWK    Critical
    Given the user navigates to sub-route    https://kite.zerodha.com
    When the client performance metrics are evaluated
    Then the page state should remain stable and error-free
    And no unhandled server error should be exposed
    And no debug stack traces should be visible
TC-P06-02-HERO: Verify Hero Headline [Login to Kite] and Primary CTA on [Landing_Auth]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE06-HERO | Priority: High]
    ...                Business Objective: Verify Hero Headline [Login to Kite] and Primary CTA on [Landing_Auth]
    ...                Acceptance Criteria: Hero section renders headline 'Login to Kite' and CTA buttons cleanly.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE06-HERO    High
    Given the user navigates to sub-route    https://kite.zerodha.com
    When the hero section is inspected
    Then the hero headline should be visible with text    Login to Kite
    And the page state should remain stable and error-free
TC-P06-03-IMG: Verify Visual Image Asset [BRAND_LOGO] Rendering & WCAG 1.1.1 Alt Text on [Landing_Auth]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE06-IMG | Priority: High]
    ...                Business Objective: Verify Visual Image Asset [BRAND_LOGO] Rendering & WCAG 1.1.1 Alt Text on [Landing_Auth]
    ...                Acceptance Criteria: Image css=img[alt='Kite logo'] (BRAND_LOGO) loads successfully and complies with WCAG 1.1.1.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE06-IMG    High
    Given the user navigates to sub-route    https://kite.zerodha.com
    When the image element is inspected    css=img[alt='Kite logo']
    Then the image asset should return HTTP 200 state
    And the image should satisfy WCAG 1.1.1 with text alternative: 'Kite logo'
    And the image should render without broken layout dimensions
TC-P06-04-BTN: Verify Action Button [Login] Clickability & State Reaction on [Landing_Auth]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE06-BTN | Priority: Critical]
    ...                Business Objective: Verify Action Button [Login] Clickability & State Reaction on [Landing_Auth]
    ...                Acceptance Criteria: Button is enabled, exhibits pointer cursor, and triggers response event without unhandled exceptions.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE06-BTN    Critical
    Given the user navigates to sub-route    https://kite.zerodha.com
    And the interactive element should be enabled    xpath=//button[contains(normalize-space(), 'Login')]
    When the user clicks the button with selector    xpath=//button[contains(normalize-space(), 'Login')]
    And the page network state stabilizes
    Then the post-action DOM state should reflect the user event    xpath=//button[contains(normalize-space(), 'Login')]
    And no unhandled server error should be exposed
TC-P06-05-FORM: Verify Form Input [userid] Constraints, Nominal Data Entry & Value Persistence on [Landing_Auth]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE06-FORM | Priority: Critical]
    ...                Business Objective: Verify Form Input [userid] Constraints, Nominal Data Entry & Value Persistence on [Landing_Auth]
    ...                Acceptance Criteria: Input field respects HTML5 constraints, accepts nominal data, and persists the entered value in the DOM.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE06-FORM    Critical
    Given the user navigates to sub-route    https://kite.zerodha.com
    When the user verifies input constraints    css=\#userid    text
    And the user enters text into input field    css=\#userid    Enterprise QA Verification
    Then the input field should retain value    css=\#userid    Enterprise QA Verification
    And the page state should remain stable and error-free
TC-P06-06-BVA: Verify Boundary Constraint Validation (Empty/Whitespace/Overlength) on [Landing_Auth]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE06-BVA | Priority: High]
    ...                Business Objective: Verify Boundary Constraint Validation (Empty/Whitespace/Overlength) on [Landing_Auth]
    ...                Acceptance Criteria: System handles boundary whitespace, length boundaries, and empty submissions with inline validation, zero 500 crashes.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE06-BVA    High
    Given the user navigates to sub-route    https://kite.zerodha.com
    When boundary test inputs or empty submissions are executed on    css=\#userid
    Then the page should handle validation gracefully without fatal errors
    And no unhandled server error should be exposed
TC-P06-08-SEC: Verify Defensive Security Isolation & Absence of Error Leaks on [Landing_Auth]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE06-SEC | Priority: Critical]
    ...                Business Objective: Verify Defensive Security Isolation & Absence of Error Leaks on [Landing_Auth]
    ...                Acceptance Criteria: Zero unhandled exceptions or sensitive debug stack traces exposed.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE06-SEC    Critical
    Given the user navigates to sub-route    https://kite.zerodha.com
    When the page DOM content and interactive elements load
    Then no unhandled server error should be exposed
    And no debug stack traces should be visible
TC-P06-11-CONCUR: Verify Simultaneous Peak Concurrency (At Same Time) Resilience on [Landing_Auth]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE06-CONCUR | Priority: Critical]
    ...                Business Objective: Verify Simultaneous Peak Concurrency (At Same Time) Resilience on [Landing_Auth]
    ...                Acceptance Criteria: System withstands simultaneous concurrent burst traffic without degradation or socket exhaustion.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE06-CONCUR    Critical
    Given a concurrent user pool of 20 virtual users
    When all virtual users launch sub-route at the exact same time    https://kite.zerodha.com
    Then the server must maintain HTTP 200 response rate above 95%
    And the response duration p(95) must remain under 3500ms SLA
    And no connection dropouts or 5xx server errors should occur
TC-P06-12-REPEAT: Verify Repeated Page Launches (Multiple Times) & TTFB Drift Consistency on [Landing_Auth]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE06-REPEAT | Priority: High]
    ...                Business Objective: Verify Repeated Page Launches (Multiple Times) & TTFB Drift Consistency on [Landing_Auth]
    ...                Acceptance Criteria: Repeated page launches exhibit consistent latency and zero server-side memory leaks.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE06-REPEAT    High
    Given an automated iteration harness configured for 10 consecutive cycles
    When the page is repeatedly loaded multiple times    https://kite.zerodha.com
    Then the Time-To-First-Byte (TTFB) must remain consistent (< 1200ms)
    And client-side caching headers must be respected
    And memory allocation must stabilize without cumulative latency drift
TC-P07-01-NAV: Verify Route Reachability, SEO Document Title & Header Layout on [Landing_General]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE07-NAV | Priority: Critical]
    ...                Business Objective: Verify Route Reachability, SEO Document Title & Header Layout on [Landing_General]
    ...                Acceptance Criteria: Page Landing_General loads with HTTP 200 state, non-empty document title, and verified header layout.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE07-NAV    Critical
    Given the user sets viewport resolution    1920    1080
    And the user navigates to sub-route    https://console.zerodha.com
    When the page DOM content and interactive elements load
    Then the destination URL should be reachable    https://console.zerodha.com
    And the page title should not be empty
    And the heading element should be visible    css=h1, h2, h3
TC-P07-01.5-FWK: Verify Modern Web Framework Integrity (React/Angular/Vue/Shadow DOM) & Zero Crash State on [Landing_General]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE07-FWK | Priority: Critical]
    ...                Business Objective: Verify Modern Web Framework Integrity (React/Angular/Vue/Shadow DOM) & Zero Crash State on [Landing_General]
    ...                Acceptance Criteria: Framework runtime on Landing_General is stable with zero hydration mismatch, unhandled promise rejections, or React/Vue error boundary crashes.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE07-FWK    Critical
    Given the user navigates to sub-route    https://console.zerodha.com
    When the client performance metrics are evaluated
    Then the page state should remain stable and error-free
    And no unhandled server error should be exposed
    And no debug stack traces should be visible
TC-P07-02-SEC: Verify Structural Sections, Container Hierarchy & Copy on [Landing_General]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE07-SEC | Priority: High]
    ...                Business Objective: Verify Structural Sections, Container Hierarchy & Copy on [Landing_General]
    ...                Acceptance Criteria: All structural containers render with correct visual hierarchy and matching copy.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE07-SEC    High
    Given the user navigates to sub-route    https://console.zerodha.com
    When the page layout structure and section containers are inspected
    Then the primary structural sections should be visible
    And the page state should remain stable and error-free
TC-P07-03-IMG: Verify Visual Image Asset [FEATURE_VISUAL] Rendering & WCAG 1.1.1 Alt Text on [Landing_General]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE07-IMG | Priority: High]
    ...                Business Objective: Verify Visual Image Asset [FEATURE_VISUAL] Rendering & WCAG 1.1.1 Alt Text on [Landing_General]
    ...                Acceptance Criteria: Image css=img[src*='tic/images/screenshot.png'] (FEATURE_VISUAL) loads successfully and complies with WCAG 1.1.1.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE07-IMG    High
    Given the user navigates to sub-route    https://console.zerodha.com
    When the image element is inspected    css=img[src*='tic/images/screenshot.png']
    Then the image asset should return HTTP 200 state
    And the image should satisfy WCAG 1.1.1 with text alternative: valid decorative alt attribute
    And the image should render without broken layout dimensions
TC-P07-04-BTN: Verify Action Button [Login with Kite] Clickability & State Reaction on [Landing_General]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE07-BTN | Priority: Critical]
    ...                Business Objective: Verify Action Button [Login with Kite] Clickability & State Reaction on [Landing_General]
    ...                Acceptance Criteria: Button is enabled, exhibits pointer cursor, and triggers response event without unhandled exceptions.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE07-BTN    Critical
    Given the user navigates to sub-route    https://console.zerodha.com
    And the interactive element should be enabled    xpath=//button[contains(normalize-space(), 'Login with Kite')]
    When the user clicks the button with selector    xpath=//button[contains(normalize-space(), 'Login with Kite')]
    And the page network state stabilizes
    Then the post-action DOM state should reflect the user event    xpath=//button[contains(normalize-space(), 'Login with Kite')]
    And no unhandled server error should be exposed
TC-P07-08-SEC: Verify Defensive Security Isolation & Absence of Error Leaks on [Landing_General]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE07-SEC | Priority: Critical]
    ...                Business Objective: Verify Defensive Security Isolation & Absence of Error Leaks on [Landing_General]
    ...                Acceptance Criteria: Zero unhandled exceptions or sensitive debug stack traces exposed.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE07-SEC    Critical
    Given the user navigates to sub-route    https://console.zerodha.com
    When the page DOM content and interactive elements load
    Then no unhandled server error should be exposed
    And no debug stack traces should be visible
TC-P07-11-CONCUR: Verify Simultaneous Peak Concurrency (At Same Time) Resilience on [Landing_General]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE07-CONCUR | Priority: Critical]
    ...                Business Objective: Verify Simultaneous Peak Concurrency (At Same Time) Resilience on [Landing_General]
    ...                Acceptance Criteria: System withstands simultaneous concurrent burst traffic without degradation or socket exhaustion.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE07-CONCUR    Critical
    Given a concurrent user pool of 20 virtual users
    When all virtual users launch sub-route at the exact same time    https://console.zerodha.com
    Then the server must maintain HTTP 200 response rate above 95%
    And the response duration p(95) must remain under 3500ms SLA
    And no connection dropouts or 5xx server errors should occur
TC-P07-12-REPEAT: Verify Repeated Page Launches (Multiple Times) & TTFB Drift Consistency on [Landing_General]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE07-REPEAT | Priority: High]
    ...                Business Objective: Verify Repeated Page Launches (Multiple Times) & TTFB Drift Consistency on [Landing_General]
    ...                Acceptance Criteria: Repeated page launches exhibit consistent latency and zero server-side memory leaks.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE07-REPEAT    High
    Given an automated iteration harness configured for 10 consecutive cycles
    When the page is repeatedly loaded multiple times    https://console.zerodha.com
    Then the Time-To-First-Byte (TTFB) must remain consistent (< 1200ms)
    And client-side caching headers must be respected
    And memory allocation must stabilize without cumulative latency drift
TC-P08-01-NAV: Verify Route Reachability, SEO Document Title & Header Layout on [Page_products_api]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE08-NAV | Priority: Critical]
    ...                Business Objective: Verify Route Reachability, SEO Document Title & Header Layout on [Page_products_api]
    ...                Acceptance Criteria: Page Page_products_api loads with HTTP 200 state, non-empty document title, and verified header layout.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE08-NAV    Critical
    Given the user sets viewport resolution    1920    1080
    And the user navigates to sub-route    https://zerodha.com/products/api/
    When the page DOM content and interactive elements load
    Then the destination URL should be reachable    https://zerodha.com/products/api/
    And the page title should not be empty
    And the heading element should be visible    css=h1, h2, h3
TC-P08-01.5-FWK: Verify Modern Web Framework Integrity (React/Angular/Vue/Shadow DOM) & Zero Crash State on [Page_products_api]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE08-FWK | Priority: Critical]
    ...                Business Objective: Verify Modern Web Framework Integrity (React/Angular/Vue/Shadow DOM) & Zero Crash State on [Page_products_api]
    ...                Acceptance Criteria: Framework runtime on Page_products_api is stable with zero hydration mismatch, unhandled promise rejections, or React/Vue error boundary crashes.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE08-FWK    Critical
    Given the user navigates to sub-route    https://zerodha.com/products/api/
    When the client performance metrics are evaluated
    Then the page state should remain stable and error-free
    And no unhandled server error should be exposed
    And no debug stack traces should be visible
TC-P08-02-SEC: Verify Structural Sections, Container Hierarchy & Copy on [Page_products_api]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE08-SEC | Priority: High]
    ...                Business Objective: Verify Structural Sections, Container Hierarchy & Copy on [Page_products_api]
    ...                Acceptance Criteria: All structural containers render with correct visual hierarchy and matching copy.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE08-SEC    High
    Given the user navigates to sub-route    https://zerodha.com/products/api/
    When the page layout structure and section containers are inspected
    Then the primary structural sections should be visible
    And the page state should remain stable and error-free
TC-P08-03-IMG: Verify Visual Image Asset [BRAND_LOGO] Rendering & WCAG 1.1.1 Alt Text on [Page_products_api]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE08-IMG | Priority: High]
    ...                Business Objective: Verify Visual Image Asset [BRAND_LOGO] Rendering & WCAG 1.1.1 Alt Text on [Page_products_api]
    ...                Acceptance Criteria: Image css=img[alt='Zerodha logo'] (BRAND_LOGO) loads successfully and complies with WCAG 1.1.1.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE08-IMG    High
    Given the user navigates to sub-route    https://zerodha.com/products/api/
    When the image element is inspected    css=img[alt='Zerodha logo']
    Then the image asset should return HTTP 200 state
    And the image should satisfy WCAG 1.1.1 with text alternative: 'Zerodha logo'
    And the image should render without broken layout dimensions
TC-P08-08-SEC: Verify Defensive Security Isolation & Absence of Error Leaks on [Page_products_api]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE08-SEC | Priority: Critical]
    ...                Business Objective: Verify Defensive Security Isolation & Absence of Error Leaks on [Page_products_api]
    ...                Acceptance Criteria: Zero unhandled exceptions or sensitive debug stack traces exposed.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE08-SEC    Critical
    Given the user navigates to sub-route    https://zerodha.com/products/api/
    When the page DOM content and interactive elements load
    Then no unhandled server error should be exposed
    And no debug stack traces should be visible
TC-P08-11-CONCUR: Verify Simultaneous Peak Concurrency (At Same Time) Resilience on [Page_products_api]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE08-CONCUR | Priority: Critical]
    ...                Business Objective: Verify Simultaneous Peak Concurrency (At Same Time) Resilience on [Page_products_api]
    ...                Acceptance Criteria: System withstands simultaneous concurrent burst traffic without degradation or socket exhaustion.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE08-CONCUR    Critical
    Given a concurrent user pool of 20 virtual users
    When all virtual users launch sub-route at the exact same time    https://zerodha.com/products/api/
    Then the server must maintain HTTP 200 response rate above 95%
    And the response duration p(95) must remain under 3500ms SLA
    And no connection dropouts or 5xx server errors should occur
TC-P08-12-REPEAT: Verify Repeated Page Launches (Multiple Times) & TTFB Drift Consistency on [Page_products_api]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE08-REPEAT | Priority: High]
    ...                Business Objective: Verify Repeated Page Launches (Multiple Times) & TTFB Drift Consistency on [Page_products_api]
    ...                Acceptance Criteria: Repeated page launches exhibit consistent latency and zero server-side memory leaks.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE08-REPEAT    High
    Given an automated iteration harness configured for 10 consecutive cycles
    When the page is repeatedly loaded multiple times    https://zerodha.com/products/api/
    Then the Time-To-First-Byte (TTFB) must remain consistent (< 1200ms)
    And client-side caching headers must be respected
    And memory allocation must stabilize without cumulative latency drift
TC-P09-01-NAV: Verify Route Reachability, SEO Document Title & Header Layout on [Landing_General]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE09-NAV | Priority: Critical]
    ...                Business Objective: Verify Route Reachability, SEO Document Title & Header Layout on [Landing_General]
    ...                Acceptance Criteria: Page Landing_General loads with HTTP 200 state, non-empty document title, and verified header layout.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE09-NAV    Critical
    Given the user sets viewport resolution    1920    1080
    And the user navigates to sub-route    https://coin.zerodha.com
    When the page DOM content and interactive elements load
    Then the destination URL should be reachable    https://coin.zerodha.com
    And the page title should not be empty
    And the heading element should be visible    css=h1, h2, h3
TC-P09-01.5-FWK: Verify Modern Web Framework Integrity (React/Angular/Vue/Shadow DOM) & Zero Crash State on [Landing_General]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE09-FWK | Priority: Critical]
    ...                Business Objective: Verify Modern Web Framework Integrity (React/Angular/Vue/Shadow DOM) & Zero Crash State on [Landing_General]
    ...                Acceptance Criteria: Framework runtime on Landing_General is stable with zero hydration mismatch, unhandled promise rejections, or React/Vue error boundary crashes.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE09-FWK    Critical
    Given the user navigates to sub-route    https://coin.zerodha.com
    When the client performance metrics are evaluated
    Then the page state should remain stable and error-free
    And no unhandled server error should be exposed
    And no debug stack traces should be visible
TC-P09-02-HERO: Verify Hero Headline [Invest in your long term ] and Primary CTA on [Landing_General]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE09-HERO | Priority: High]
    ...                Business Objective: Verify Hero Headline [Invest in your long term ] and Primary CTA on [Landing_General]
    ...                Acceptance Criteria: Hero section renders headline 'Invest in your long term finan' and CTA buttons cleanly.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE09-HERO    High
    Given the user navigates to sub-route    https://coin.zerodha.com
    When the hero section is inspected
    Then the hero headline should be visible with text    Invest in your long term financial goals
    And the page state should remain stable and error-free
TC-P09-03-IMG: Verify Visual Image Asset [BRAND_LOGO] Rendering & WCAG 1.1.1 Alt Text on [Landing_General]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE09-IMG | Priority: High]
    ...                Business Objective: Verify Visual Image Asset [BRAND_LOGO] Rendering & WCAG 1.1.1 Alt Text on [Landing_General]
    ...                Acceptance Criteria: Image css=img[alt='Coin by Zerodha'] (BRAND_LOGO) loads successfully and complies with WCAG 1.1.1.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE09-IMG    High
    Given the user navigates to sub-route    https://coin.zerodha.com
    When the image element is inspected    css=img[alt='Coin by Zerodha']
    Then the image asset should return HTTP 200 state
    And the image should satisfy WCAG 1.1.1 with text alternative: 'Coin by Zerodha'
    And the image should render without broken layout dimensions
TC-P09-08-SEC: Verify Defensive Security Isolation & Absence of Error Leaks on [Landing_General]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE09-SEC | Priority: Critical]
    ...                Business Objective: Verify Defensive Security Isolation & Absence of Error Leaks on [Landing_General]
    ...                Acceptance Criteria: Zero unhandled exceptions or sensitive debug stack traces exposed.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE09-SEC    Critical
    Given the user navigates to sub-route    https://coin.zerodha.com
    When the page DOM content and interactive elements load
    Then no unhandled server error should be exposed
    And no debug stack traces should be visible
TC-P09-11-CONCUR: Verify Simultaneous Peak Concurrency (At Same Time) Resilience on [Landing_General]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE09-CONCUR | Priority: Critical]
    ...                Business Objective: Verify Simultaneous Peak Concurrency (At Same Time) Resilience on [Landing_General]
    ...                Acceptance Criteria: System withstands simultaneous concurrent burst traffic without degradation or socket exhaustion.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE09-CONCUR    Critical
    Given a concurrent user pool of 20 virtual users
    When all virtual users launch sub-route at the exact same time    https://coin.zerodha.com
    Then the server must maintain HTTP 200 response rate above 95%
    And the response duration p(95) must remain under 3500ms SLA
    And no connection dropouts or 5xx server errors should occur
TC-P09-12-REPEAT: Verify Repeated Page Launches (Multiple Times) & TTFB Drift Consistency on [Landing_General]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE09-REPEAT | Priority: High]
    ...                Business Objective: Verify Repeated Page Launches (Multiple Times) & TTFB Drift Consistency on [Landing_General]
    ...                Acceptance Criteria: Repeated page launches exhibit consistent latency and zero server-side memory leaks.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE09-REPEAT    High
    Given an automated iteration harness configured for 10 consecutive cycles
    When the page is repeatedly loaded multiple times    https://coin.zerodha.com
    Then the Time-To-First-Byte (TTFB) must remain consistent (< 1200ms)
    And client-side caching headers must be respected
    And memory allocation must stabilize without cumulative latency drift
TC-P10-01-NAV: Verify Route Reachability, SEO Document Title & Header Layout on [Page_varsity]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE10-NAV | Priority: Critical]
    ...                Business Objective: Verify Route Reachability, SEO Document Title & Header Layout on [Page_varsity]
    ...                Acceptance Criteria: Page Page_varsity loads with HTTP 200 state, non-empty document title, and verified header layout.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE10-NAV    Critical
    Given the user sets viewport resolution    1920    1080
    And the user navigates to sub-route    https://zerodha.com/varsity/
    When the page DOM content and interactive elements load
    Then the destination URL should be reachable    https://zerodha.com/varsity/
    And the page title should not be empty
    And the heading element should be visible    css=h1, h2, h3
TC-P10-01.5-FWK: Verify Modern Web Framework Integrity (React/Angular/Vue/Shadow DOM) & Zero Crash State on [Page_varsity]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE10-FWK | Priority: Critical]
    ...                Business Objective: Verify Modern Web Framework Integrity (React/Angular/Vue/Shadow DOM) & Zero Crash State on [Page_varsity]
    ...                Acceptance Criteria: Framework runtime on Page_varsity is stable with zero hydration mismatch, unhandled promise rejections, or React/Vue error boundary crashes.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE10-FWK    Critical
    Given the user navigates to sub-route    https://zerodha.com/varsity/
    When the client performance metrics are evaluated
    Then the page state should remain stable and error-free
    And no unhandled server error should be exposed
    And no debug stack traces should be visible
TC-P10-02-SEC: Verify Structural Sections, Container Hierarchy & Copy on [Page_varsity]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE10-SEC | Priority: High]
    ...                Business Objective: Verify Structural Sections, Container Hierarchy & Copy on [Page_varsity]
    ...                Acceptance Criteria: All structural containers render with correct visual hierarchy and matching copy.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE10-SEC    High
    Given the user navigates to sub-route    https://zerodha.com/varsity/
    When the page layout structure and section containers are inspected
    Then the primary structural sections should be visible
    And the page state should remain stable and error-free
TC-P10-08-SEC: Verify Defensive Security Isolation & Absence of Error Leaks on [Page_varsity]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE10-SEC | Priority: Critical]
    ...                Business Objective: Verify Defensive Security Isolation & Absence of Error Leaks on [Page_varsity]
    ...                Acceptance Criteria: Zero unhandled exceptions or sensitive debug stack traces exposed.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE10-SEC    Critical
    Given the user navigates to sub-route    https://zerodha.com/varsity/
    When the page DOM content and interactive elements load
    Then no unhandled server error should be exposed
    And no debug stack traces should be visible
TC-P10-11-CONCUR: Verify Simultaneous Peak Concurrency (At Same Time) Resilience on [Page_varsity]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE10-CONCUR | Priority: Critical]
    ...                Business Objective: Verify Simultaneous Peak Concurrency (At Same Time) Resilience on [Page_varsity]
    ...                Acceptance Criteria: System withstands simultaneous concurrent burst traffic without degradation or socket exhaustion.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE10-CONCUR    Critical
    Given a concurrent user pool of 20 virtual users
    When all virtual users launch sub-route at the exact same time    https://zerodha.com/varsity/
    Then the server must maintain HTTP 200 response rate above 95%
    And the response duration p(95) must remain under 3500ms SLA
    And no connection dropouts or 5xx server errors should occur
TC-P10-12-REPEAT: Verify Repeated Page Launches (Multiple Times) & TTFB Drift Consistency on [Page_varsity]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE10-REPEAT | Priority: High]
    ...                Business Objective: Verify Repeated Page Launches (Multiple Times) & TTFB Drift Consistency on [Page_varsity]
    ...                Acceptance Criteria: Repeated page launches exhibit consistent latency and zero server-side memory leaks.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE10-REPEAT    High
    Given an automated iteration harness configured for 10 consecutive cycles
    When the page is repeatedly loaded multiple times    https://zerodha.com/varsity/
    Then the Time-To-First-Byte (TTFB) must remain consistent (< 1200ms)
    And client-side caching headers must be respected
    And memory allocation must stabilize without cumulative latency drift
TC-P11-01-NAV: Verify Route Reachability, SEO Document Title & Header Layout on [Page_calculators]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE11-NAV | Priority: Critical]
    ...                Business Objective: Verify Route Reachability, SEO Document Title & Header Layout on [Page_calculators]
    ...                Acceptance Criteria: Page Page_calculators loads with HTTP 200 state, non-empty document title, and verified header layout.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE11-NAV    Critical
    Given the user sets viewport resolution    1920    1080
    And the user navigates to sub-route    https://zerodha.com/calculators/
    When the page DOM content and interactive elements load
    Then the destination URL should be reachable    https://zerodha.com/calculators/
    And the page title should not be empty
    And the heading element should be visible    css=h1, h2, h3
TC-P11-01.5-FWK: Verify Modern Web Framework Integrity (React/Angular/Vue/Shadow DOM) & Zero Crash State on [Page_calculators]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE11-FWK | Priority: Critical]
    ...                Business Objective: Verify Modern Web Framework Integrity (React/Angular/Vue/Shadow DOM) & Zero Crash State on [Page_calculators]
    ...                Acceptance Criteria: Framework runtime on Page_calculators is stable with zero hydration mismatch, unhandled promise rejections, or React/Vue error boundary crashes.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE11-FWK    Critical
    Given the user navigates to sub-route    https://zerodha.com/calculators/
    When the client performance metrics are evaluated
    Then the page state should remain stable and error-free
    And no unhandled server error should be exposed
    And no debug stack traces should be visible
TC-P11-02-SEC: Verify Structural Sections, Container Hierarchy & Copy on [Page_calculators]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE11-SEC | Priority: High]
    ...                Business Objective: Verify Structural Sections, Container Hierarchy & Copy on [Page_calculators]
    ...                Acceptance Criteria: All structural containers render with correct visual hierarchy and matching copy.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE11-SEC    High
    Given the user navigates to sub-route    https://zerodha.com/calculators/
    When the page layout structure and section containers are inspected
    Then the primary structural sections should be visible
    And the page state should remain stable and error-free
TC-P11-04-BTN: Verify Action Button [Open main menu] Clickability & State Reaction on [Page_calculators]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE11-BTN | Priority: Critical]
    ...                Business Objective: Verify Action Button [Open main menu] Clickability & State Reaction on [Page_calculators]
    ...                Acceptance Criteria: Button is enabled, exhibits pointer cursor, and triggers response event without unhandled exceptions.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE11-BTN    Critical
    Given the user navigates to sub-route    https://zerodha.com/calculators/
    And the interactive element should be enabled    css=button.relative
    When the user clicks the button with selector    css=button.relative
    And the page network state stabilizes
    Then the post-action DOM state should reflect the user event    css=button.relative
    And no unhandled server error should be exposed
TC-P11-05-FORM: Verify Form Input [user_mobile] Constraints, Nominal Data Entry & Value Persistence on [Page_calculators]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE11-FORM | Priority: Critical]
    ...                Business Objective: Verify Form Input [user_mobile] Constraints, Nominal Data Entry & Value Persistence on [Page_calculators]
    ...                Acceptance Criteria: Input field respects HTML5 constraints, accepts nominal data, and persists the entered value in the DOM.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE11-FORM    Critical
    Given the user navigates to sub-route    https://zerodha.com/calculators/
    When the user verifies input constraints    css=\#user_mobile    number
    And the user enters text into input field    css=\#user_mobile    Enterprise QA Verification
    Then the input field should retain value    css=\#user_mobile    Enterprise QA Verification
    And the page state should remain stable and error-free
TC-P11-06-BVA: Verify Boundary Constraint Validation (Empty/Whitespace/Overlength) on [Page_calculators]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE11-BVA | Priority: High]
    ...                Business Objective: Verify Boundary Constraint Validation (Empty/Whitespace/Overlength) on [Page_calculators]
    ...                Acceptance Criteria: System handles boundary whitespace, length boundaries, and empty submissions with inline validation, zero 500 crashes.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE11-BVA    High
    Given the user navigates to sub-route    https://zerodha.com/calculators/
    When boundary test inputs or empty submissions are executed on    css=\#user_mobile
    Then the page should handle validation gracefully without fatal errors
    And no unhandled server error should be exposed
TC-P11-08-SEC: Verify Defensive Security Isolation & Absence of Error Leaks on [Page_calculators]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE11-SEC | Priority: Critical]
    ...                Business Objective: Verify Defensive Security Isolation & Absence of Error Leaks on [Page_calculators]
    ...                Acceptance Criteria: Zero unhandled exceptions or sensitive debug stack traces exposed.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE11-SEC    Critical
    Given the user navigates to sub-route    https://zerodha.com/calculators/
    When the page DOM content and interactive elements load
    Then no unhandled server error should be exposed
    And no debug stack traces should be visible
TC-P11-11-CONCUR: Verify Simultaneous Peak Concurrency (At Same Time) Resilience on [Page_calculators]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE11-CONCUR | Priority: Critical]
    ...                Business Objective: Verify Simultaneous Peak Concurrency (At Same Time) Resilience on [Page_calculators]
    ...                Acceptance Criteria: System withstands simultaneous concurrent burst traffic without degradation or socket exhaustion.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE11-CONCUR    Critical
    Given a concurrent user pool of 20 virtual users
    When all virtual users launch sub-route at the exact same time    https://zerodha.com/calculators/
    Then the server must maintain HTTP 200 response rate above 95%
    And the response duration p(95) must remain under 3500ms SLA
    And no connection dropouts or 5xx server errors should occur
TC-P11-12-REPEAT: Verify Repeated Page Launches (Multiple Times) & TTFB Drift Consistency on [Page_calculators]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE11-REPEAT | Priority: High]
    ...                Business Objective: Verify Repeated Page Launches (Multiple Times) & TTFB Drift Consistency on [Page_calculators]
    ...                Acceptance Criteria: Repeated page launches exhibit consistent latency and zero server-side memory leaks.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE11-REPEAT    High
    Given an automated iteration harness configured for 10 consecutive cycles
    When the page is repeatedly loaded multiple times    https://zerodha.com/calculators/
    Then the Time-To-First-Byte (TTFB) must remain consistent (< 1200ms)
    And client-side caching headers must be respected
    And memory allocation must stabilize without cumulative latency drift
TC-P12-01-NAV: Verify Route Reachability, SEO Document Title & Header Layout on [Page_brokerage_calculator]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE12-NAV | Priority: Critical]
    ...                Business Objective: Verify Route Reachability, SEO Document Title & Header Layout on [Page_brokerage_calculator]
    ...                Acceptance Criteria: Page Page_brokerage_calculator loads with HTTP 200 state, non-empty document title, and verified header layout.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE12-NAV    Critical
    Given the user sets viewport resolution    1920    1080
    And the user navigates to sub-route    https://zerodha.com/brokerage-calculator/
    When the page DOM content and interactive elements load
    Then the destination URL should be reachable    https://zerodha.com/brokerage-calculator/
    And the page title should not be empty
    And the heading element should be visible    css=h1, h2, h3
TC-P12-01.5-FWK: Verify Modern Web Framework Integrity (React/Angular/Vue/Shadow DOM) & Zero Crash State on [Page_brokerage_calculator]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE12-FWK | Priority: Critical]
    ...                Business Objective: Verify Modern Web Framework Integrity (React/Angular/Vue/Shadow DOM) & Zero Crash State on [Page_brokerage_calculator]
    ...                Acceptance Criteria: Framework runtime on Page_brokerage_calculator is stable with zero hydration mismatch, unhandled promise rejections, or React/Vue error boundary crashes.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE12-FWK    Critical
    Given the user navigates to sub-route    https://zerodha.com/brokerage-calculator/
    When the client performance metrics are evaluated
    Then the page state should remain stable and error-free
    And no unhandled server error should be exposed
    And no debug stack traces should be visible
TC-P12-02-SEC: Verify Structural Sections, Container Hierarchy & Copy on [Page_brokerage_calculator]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE12-SEC | Priority: High]
    ...                Business Objective: Verify Structural Sections, Container Hierarchy & Copy on [Page_brokerage_calculator]
    ...                Acceptance Criteria: All structural containers render with correct visual hierarchy and matching copy.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE12-SEC    High
    Given the user navigates to sub-route    https://zerodha.com/brokerage-calculator/
    When the page layout structure and section containers are inspected
    Then the primary structural sections should be visible
    And the page state should remain stable and error-free
TC-P12-04-BTN: Verify Action Button [+ Contract note] Clickability & State Reaction on [Page_brokerage_calculator]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE12-BTN | Priority: Critical]
    ...                Business Objective: Verify Action Button [+ Contract note] Clickability & State Reaction on [Page_brokerage_calculator]
    ...                Acceptance Criteria: Button is enabled, exhibits pointer cursor, and triggers response event without unhandled exceptions.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE12-BTN    Critical
    Given the user navigates to sub-route    https://zerodha.com/brokerage-calculator/
    And the interactive element should be enabled    css=\#intra_ecn
    When the user clicks the button with selector    css=\#intra_ecn
    And the page network state stabilizes
    Then the post-action DOM state should reflect the user event    css=\#intra_ecn
    And no unhandled server error should be exposed
TC-P12-05-FORM: Verify Form Input [input] Constraints, Nominal Data Entry & Value Persistence on [Page_brokerage_calculator]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE12-FORM | Priority: Critical]
    ...                Business Objective: Verify Form Input [input] Constraints, Nominal Data Entry & Value Persistence on [Page_brokerage_calculator]
    ...                Acceptance Criteria: Input field respects HTML5 constraints, accepts nominal data, and persists the entered value in the DOM.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE12-FORM    Critical
    Given the user navigates to sub-route    https://zerodha.com/brokerage-calculator/
    When the user verifies input constraints    css=input[type='number']    number
    And the user enters text into input field    css=input[type='number']    Enterprise QA Verification
    Then the input field should retain value    css=input[type='number']    Enterprise QA Verification
    And the page state should remain stable and error-free
TC-P12-06-BVA: Verify Boundary Constraint Validation (Empty/Whitespace/Overlength) on [Page_brokerage_calculator]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE12-BVA | Priority: High]
    ...                Business Objective: Verify Boundary Constraint Validation (Empty/Whitespace/Overlength) on [Page_brokerage_calculator]
    ...                Acceptance Criteria: System handles boundary whitespace, length boundaries, and empty submissions with inline validation, zero 500 crashes.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE12-BVA    High
    Given the user navigates to sub-route    https://zerodha.com/brokerage-calculator/
    When boundary test inputs or empty submissions are executed on    css=input[type='number']
    Then the page should handle validation gracefully without fatal errors
    And no unhandled server error should be exposed
TC-P12-07-DD: Verify Dropdown Selection Control [commodity_multiplier_fut] & Options Population on [Page_brokerage_calculator]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE12-DD | Priority: Medium]
    ...                Business Objective: Verify Dropdown Selection Control [commodity_multiplier_fut] & Options Population on [Page_brokerage_calculator]
    ...                Acceptance Criteria: Dropdown options populate valid values, respond to user selection, and dispatch change events.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE12-DD    Medium
    Given the user navigates to sub-route    https://zerodha.com/brokerage-calculator/
    When dropdown with selector is interacted with    css=\#commodity_multiplier_fut
    Then the page state should remain stable and error-free
TC-P12-08-SEC: Verify Defensive Security Isolation & Absence of Error Leaks on [Page_brokerage_calculator]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE12-SEC | Priority: Critical]
    ...                Business Objective: Verify Defensive Security Isolation & Absence of Error Leaks on [Page_brokerage_calculator]
    ...                Acceptance Criteria: Zero unhandled exceptions or sensitive debug stack traces exposed.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE12-SEC    Critical
    Given the user navigates to sub-route    https://zerodha.com/brokerage-calculator/
    When the page DOM content and interactive elements load
    Then no unhandled server error should be exposed
    And no debug stack traces should be visible
TC-P12-11-CONCUR: Verify Simultaneous Peak Concurrency (At Same Time) Resilience on [Page_brokerage_calculator]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE12-CONCUR | Priority: Critical]
    ...                Business Objective: Verify Simultaneous Peak Concurrency (At Same Time) Resilience on [Page_brokerage_calculator]
    ...                Acceptance Criteria: System withstands simultaneous concurrent burst traffic without degradation or socket exhaustion.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE12-CONCUR    Critical
    Given a concurrent user pool of 20 virtual users
    When all virtual users launch sub-route at the exact same time    https://zerodha.com/brokerage-calculator/
    Then the server must maintain HTTP 200 response rate above 95%
    And the response duration p(95) must remain under 3500ms SLA
    And no connection dropouts or 5xx server errors should occur
TC-P12-12-REPEAT: Verify Repeated Page Launches (Multiple Times) & TTFB Drift Consistency on [Page_brokerage_calculator]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE12-REPEAT | Priority: High]
    ...                Business Objective: Verify Repeated Page Launches (Multiple Times) & TTFB Drift Consistency on [Page_brokerage_calculator]
    ...                Acceptance Criteria: Repeated page launches exhibit consistent latency and zero server-side memory leaks.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE12-REPEAT    High
    Given an automated iteration harness configured for 10 consecutive cycles
    When the page is repeatedly loaded multiple times    https://zerodha.com/brokerage-calculator/
    Then the Time-To-First-Byte (TTFB) must remain consistent (< 1200ms)
    And client-side caching headers must be respected
    And memory allocation must stabilize without cumulative latency drift
TC-P13-01-NAV: Verify Route Reachability, SEO Document Title & Header Layout on [Page_margin_calculator]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE13-NAV | Priority: Critical]
    ...                Business Objective: Verify Route Reachability, SEO Document Title & Header Layout on [Page_margin_calculator]
    ...                Acceptance Criteria: Page Page_margin_calculator loads with HTTP 200 state, non-empty document title, and verified header layout.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE13-NAV    Critical
    Given the user sets viewport resolution    1920    1080
    And the user navigates to sub-route    https://zerodha.com/margin-calculator/
    When the page DOM content and interactive elements load
    Then the destination URL should be reachable    https://zerodha.com/margin-calculator/
    And the page title should not be empty
    And the heading element should be visible    css=h1, h2, h3
TC-P13-01.5-FWK: Verify Modern Web Framework Integrity (React/Angular/Vue/Shadow DOM) & Zero Crash State on [Page_margin_calculator]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE13-FWK | Priority: Critical]
    ...                Business Objective: Verify Modern Web Framework Integrity (React/Angular/Vue/Shadow DOM) & Zero Crash State on [Page_margin_calculator]
    ...                Acceptance Criteria: Framework runtime on Page_margin_calculator is stable with zero hydration mismatch, unhandled promise rejections, or React/Vue error boundary crashes.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE13-FWK    Critical
    Given the user navigates to sub-route    https://zerodha.com/margin-calculator/
    When the client performance metrics are evaluated
    Then the page state should remain stable and error-free
    And no unhandled server error should be exposed
    And no debug stack traces should be visible
TC-P13-02-SEC: Verify Structural Sections, Container Hierarchy & Copy on [Page_margin_calculator]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE13-SEC | Priority: High]
    ...                Business Objective: Verify Structural Sections, Container Hierarchy & Copy on [Page_margin_calculator]
    ...                Acceptance Criteria: All structural containers render with correct visual hierarchy and matching copy.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE13-SEC    High
    Given the user navigates to sub-route    https://zerodha.com/margin-calculator/
    When the page layout structure and section containers are inspected
    Then the primary structural sections should be visible
    And the page state should remain stable and error-free
TC-P13-05-FORM: Verify Form Input [strike_price[]] Constraints, Nominal Data Entry & Value Persistence on [Page_margin_calculator]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE13-FORM | Priority: Critical]
    ...                Business Objective: Verify Form Input [strike_price[]] Constraints, Nominal Data Entry & Value Persistence on [Page_margin_calculator]
    ...                Acceptance Criteria: Input field respects HTML5 constraints, accepts nominal data, and persists the entered value in the DOM.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE13-FORM    Critical
    Given the user navigates to sub-route    https://zerodha.com/margin-calculator/
    When the user verifies input constraints    css=\#strike_price    text
    And the user enters text into input field    css=\#strike_price    Enterprise QA Verification
    Then the input field should retain value    css=\#strike_price    Enterprise QA Verification
    And the page state should remain stable and error-free
TC-P13-06-BVA: Verify Boundary Constraint Validation (Empty/Whitespace/Overlength) on [Page_margin_calculator]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE13-BVA | Priority: High]
    ...                Business Objective: Verify Boundary Constraint Validation (Empty/Whitespace/Overlength) on [Page_margin_calculator]
    ...                Acceptance Criteria: System handles boundary whitespace, length boundaries, and empty submissions with inline validation, zero 500 crashes.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE13-BVA    High
    Given the user navigates to sub-route    https://zerodha.com/margin-calculator/
    When boundary test inputs or empty submissions are executed on    css=\#strike_price
    Then the page should handle validation gracefully without fatal errors
    And no unhandled server error should be exposed
TC-P13-07-DD: Verify Dropdown Selection Control [exchange[]] & Options Population on [Page_margin_calculator]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE13-DD | Priority: Medium]
    ...                Business Objective: Verify Dropdown Selection Control [exchange[]] & Options Population on [Page_margin_calculator]
    ...                Acceptance Criteria: Dropdown options populate valid values, respond to user selection, and dispatch change events.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE13-DD    Medium
    Given the user navigates to sub-route    https://zerodha.com/margin-calculator/
    When dropdown with selector is interacted with    css=\#exchange
    Then the page state should remain stable and error-free
TC-P13-08-SEC: Verify Defensive Security Isolation & Absence of Error Leaks on [Page_margin_calculator]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE13-SEC | Priority: Critical]
    ...                Business Objective: Verify Defensive Security Isolation & Absence of Error Leaks on [Page_margin_calculator]
    ...                Acceptance Criteria: Zero unhandled exceptions or sensitive debug stack traces exposed.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE13-SEC    Critical
    Given the user navigates to sub-route    https://zerodha.com/margin-calculator/
    When the page DOM content and interactive elements load
    Then no unhandled server error should be exposed
    And no debug stack traces should be visible
TC-P13-11-CONCUR: Verify Simultaneous Peak Concurrency (At Same Time) Resilience on [Page_margin_calculator]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE13-CONCUR | Priority: Critical]
    ...                Business Objective: Verify Simultaneous Peak Concurrency (At Same Time) Resilience on [Page_margin_calculator]
    ...                Acceptance Criteria: System withstands simultaneous concurrent burst traffic without degradation or socket exhaustion.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE13-CONCUR    Critical
    Given a concurrent user pool of 20 virtual users
    When all virtual users launch sub-route at the exact same time    https://zerodha.com/margin-calculator/
    Then the server must maintain HTTP 200 response rate above 95%
    And the response duration p(95) must remain under 3500ms SLA
    And no connection dropouts or 5xx server errors should occur
TC-P13-12-REPEAT: Verify Repeated Page Launches (Multiple Times) & TTFB Drift Consistency on [Page_margin_calculator]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE13-REPEAT | Priority: High]
    ...                Business Objective: Verify Repeated Page Launches (Multiple Times) & TTFB Drift Consistency on [Page_margin_calculator]
    ...                Acceptance Criteria: Repeated page launches exhibit consistent latency and zero server-side memory leaks.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE13-REPEAT    High
    Given an automated iteration harness configured for 10 consecutive cycles
    When the page is repeatedly loaded multiple times    https://zerodha.com/margin-calculator/
    Then the Time-To-First-Byte (TTFB) must remain consistent (< 1200ms)
    And client-side caching headers must be respected
    And memory allocation must stabilize without cumulative latency drift
TC-P14-01-NAV: Verify Route Reachability, SEO Document Title & Header Layout on [Page_calculators_sip_calc]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE14-NAV | Priority: Critical]
    ...                Business Objective: Verify Route Reachability, SEO Document Title & Header Layout on [Page_calculators_sip_calc]
    ...                Acceptance Criteria: Page Page_calculators_sip_calc loads with HTTP 200 state, non-empty document title, and verified header layout.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE14-NAV    Critical
    Given the user sets viewport resolution    1920    1080
    And the user navigates to sub-route    https://zerodha.com/calculators/sip-calculator/
    When the page DOM content and interactive elements load
    Then the destination URL should be reachable    https://zerodha.com/calculators/sip-calculator/
    And the page title should not be empty
    And the heading element should be visible    css=h1, h2, h3
TC-P14-01.5-FWK: Verify Modern Web Framework Integrity (React/Angular/Vue/Shadow DOM) & Zero Crash State on [Page_calculators_sip_calc]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE14-FWK | Priority: Critical]
    ...                Business Objective: Verify Modern Web Framework Integrity (React/Angular/Vue/Shadow DOM) & Zero Crash State on [Page_calculators_sip_calc]
    ...                Acceptance Criteria: Framework runtime on Page_calculators_sip_calc is stable with zero hydration mismatch, unhandled promise rejections, or React/Vue error boundary crashes.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE14-FWK    Critical
    Given the user navigates to sub-route    https://zerodha.com/calculators/sip-calculator/
    When the client performance metrics are evaluated
    Then the page state should remain stable and error-free
    And no unhandled server error should be exposed
    And no debug stack traces should be visible
TC-P14-02-SEC: Verify Structural Sections, Container Hierarchy & Copy on [Page_calculators_sip_calc]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE14-SEC | Priority: High]
    ...                Business Objective: Verify Structural Sections, Container Hierarchy & Copy on [Page_calculators_sip_calc]
    ...                Acceptance Criteria: All structural containers render with correct visual hierarchy and matching copy.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE14-SEC    High
    Given the user navigates to sub-route    https://zerodha.com/calculators/sip-calculator/
    When the page layout structure and section containers are inspected
    Then the primary structural sections should be visible
    And the page state should remain stable and error-free
TC-P14-04-BTN: Verify Action Button [Open main menu] Clickability & State Reaction on [Page_calculators_sip_calc]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE14-BTN | Priority: Critical]
    ...                Business Objective: Verify Action Button [Open main menu] Clickability & State Reaction on [Page_calculators_sip_calc]
    ...                Acceptance Criteria: Button is enabled, exhibits pointer cursor, and triggers response event without unhandled exceptions.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE14-BTN    Critical
    Given the user navigates to sub-route    https://zerodha.com/calculators/sip-calculator/
    And the interactive element should be enabled    css=button.relative
    When the user clicks the button with selector    css=button.relative
    And the page network state stabilizes
    Then the post-action DOM state should reflect the user event    css=button.relative
    And no unhandled server error should be exposed
TC-P14-05-FORM: Verify Form Input [user_mobile] Constraints, Nominal Data Entry & Value Persistence on [Page_calculators_sip_calc]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE14-FORM | Priority: Critical]
    ...                Business Objective: Verify Form Input [user_mobile] Constraints, Nominal Data Entry & Value Persistence on [Page_calculators_sip_calc]
    ...                Acceptance Criteria: Input field respects HTML5 constraints, accepts nominal data, and persists the entered value in the DOM.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE14-FORM    Critical
    Given the user navigates to sub-route    https://zerodha.com/calculators/sip-calculator/
    When the user verifies input constraints    css=\#user_mobile    number
    And the user enters text into input field    css=\#user_mobile    Enterprise QA Verification
    Then the input field should retain value    css=\#user_mobile    Enterprise QA Verification
    And the page state should remain stable and error-free
TC-P14-06-BVA: Verify Boundary Constraint Validation (Empty/Whitespace/Overlength) on [Page_calculators_sip_calc]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE14-BVA | Priority: High]
    ...                Business Objective: Verify Boundary Constraint Validation (Empty/Whitespace/Overlength) on [Page_calculators_sip_calc]
    ...                Acceptance Criteria: System handles boundary whitespace, length boundaries, and empty submissions with inline validation, zero 500 crashes.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE14-BVA    High
    Given the user navigates to sub-route    https://zerodha.com/calculators/sip-calculator/
    When boundary test inputs or empty submissions are executed on    css=\#user_mobile
    Then the page should handle validation gracefully without fatal errors
    And no unhandled server error should be exposed
TC-P14-07-DD: Verify Dropdown Selection Control [select] & Options Population on [Page_calculators_sip_calc]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE14-DD | Priority: Medium]
    ...                Business Objective: Verify Dropdown Selection Control [select] & Options Population on [Page_calculators_sip_calc]
    ...                Acceptance Criteria: Dropdown options populate valid values, respond to user selection, and dispatch change events.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE14-DD    Medium
    Given the user navigates to sub-route    https://zerodha.com/calculators/sip-calculator/
    When dropdown with selector is interacted with    css=select
    Then the page state should remain stable and error-free
TC-P14-08-SEC: Verify Defensive Security Isolation & Absence of Error Leaks on [Page_calculators_sip_calc]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE14-SEC | Priority: Critical]
    ...                Business Objective: Verify Defensive Security Isolation & Absence of Error Leaks on [Page_calculators_sip_calc]
    ...                Acceptance Criteria: Zero unhandled exceptions or sensitive debug stack traces exposed.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE14-SEC    Critical
    Given the user navigates to sub-route    https://zerodha.com/calculators/sip-calculator/
    When the page DOM content and interactive elements load
    Then no unhandled server error should be exposed
    And no debug stack traces should be visible
TC-P14-11-CONCUR: Verify Simultaneous Peak Concurrency (At Same Time) Resilience on [Page_calculators_sip_calc]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE14-CONCUR | Priority: Critical]
    ...                Business Objective: Verify Simultaneous Peak Concurrency (At Same Time) Resilience on [Page_calculators_sip_calc]
    ...                Acceptance Criteria: System withstands simultaneous concurrent burst traffic without degradation or socket exhaustion.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE14-CONCUR    Critical
    Given a concurrent user pool of 20 virtual users
    When all virtual users launch sub-route at the exact same time    https://zerodha.com/calculators/sip-calculator/
    Then the server must maintain HTTP 200 response rate above 95%
    And the response duration p(95) must remain under 3500ms SLA
    And no connection dropouts or 5xx server errors should occur
TC-P14-12-REPEAT: Verify Repeated Page Launches (Multiple Times) & TTFB Drift Consistency on [Page_calculators_sip_calc]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE14-REPEAT | Priority: High]
    ...                Business Objective: Verify Repeated Page Launches (Multiple Times) & TTFB Drift Consistency on [Page_calculators_sip_calc]
    ...                Acceptance Criteria: Repeated page launches exhibit consistent latency and zero server-side memory leaks.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE14-REPEAT    High
    Given an automated iteration harness configured for 10 consecutive cycles
    When the page is repeatedly loaded multiple times    https://zerodha.com/calculators/sip-calculator/
    Then the Time-To-First-Byte (TTFB) must remain consistent (< 1200ms)
    And client-side caching headers must be respected
    And memory allocation must stabilize without cumulative latency drift
TC-P15-01-NAV: Verify Route Reachability, SEO Document Title & Header Layout on [Page_z_connect]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE15-NAV | Priority: Critical]
    ...                Business Objective: Verify Route Reachability, SEO Document Title & Header Layout on [Page_z_connect]
    ...                Acceptance Criteria: Page Page_z_connect loads with HTTP 200 state, non-empty document title, and verified header layout.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE15-NAV    Critical
    Given the user sets viewport resolution    1920    1080
    And the user navigates to sub-route    https://zerodha.com/z-connect/
    When the page DOM content and interactive elements load
    Then the destination URL should be reachable    https://zerodha.com/z-connect/
    And the page title should not be empty
    And the heading element should be visible    css=h1, h2, h3
TC-P15-01.5-FWK: Verify Modern Web Framework Integrity (React/Angular/Vue/Shadow DOM) & Zero Crash State on [Page_z_connect]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE15-FWK | Priority: Critical]
    ...                Business Objective: Verify Modern Web Framework Integrity (React/Angular/Vue/Shadow DOM) & Zero Crash State on [Page_z_connect]
    ...                Acceptance Criteria: Framework runtime on Page_z_connect is stable with zero hydration mismatch, unhandled promise rejections, or React/Vue error boundary crashes.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE15-FWK    Critical
    Given the user navigates to sub-route    https://zerodha.com/z-connect/
    When the client performance metrics are evaluated
    Then the page state should remain stable and error-free
    And no unhandled server error should be exposed
    And no debug stack traces should be visible
TC-P15-02-SEC: Verify Structural Sections, Container Hierarchy & Copy on [Page_z_connect]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE15-SEC | Priority: High]
    ...                Business Objective: Verify Structural Sections, Container Hierarchy & Copy on [Page_z_connect]
    ...                Acceptance Criteria: All structural containers render with correct visual hierarchy and matching copy.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE15-SEC    High
    Given the user navigates to sub-route    https://zerodha.com/z-connect/
    When the page layout structure and section containers are inspected
    Then the primary structural sections should be visible
    And the page state should remain stable and error-free
TC-P15-04-BTN: Verify Action Button [Subscribe] Clickability & State Reaction on [Page_z_connect]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE15-BTN | Priority: Critical]
    ...                Business Objective: Verify Action Button [Subscribe] Clickability & State Reaction on [Page_z_connect]
    ...                Acceptance Criteria: Button is enabled, exhibits pointer cursor, and triggers response event without unhandled exceptions.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE15-BTN    Critical
    Given the user navigates to sub-route    https://zerodha.com/z-connect/
    And the interactive element should be enabled    css=button.primary
    When the user clicks the button with selector    css=button.primary
    And the page network state stabilizes
    Then the post-action DOM state should reflect the user event    css=button.primary
    And no unhandled server error should be exposed
TC-P15-05-FORM: Verify Form Input [s] Constraints, Nominal Data Entry & Value Persistence on [Page_z_connect]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE15-FORM | Priority: Critical]
    ...                Business Objective: Verify Form Input [s] Constraints, Nominal Data Entry & Value Persistence on [Page_z_connect]
    ...                Acceptance Criteria: Input field respects HTML5 constraints, accepts nominal data, and persists the entered value in the DOM.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE15-FORM    Critical
    Given the user navigates to sub-route    https://zerodha.com/z-connect/
    When the user verifies input constraints    css=input[name='s']    text
    And the user enters text into input field    css=input[name='s']    Enterprise QA Verification
    Then the input field should retain value    css=input[name='s']    Enterprise QA Verification
    And the page state should remain stable and error-free
TC-P15-06-BVA: Verify Boundary Constraint Validation (Empty/Whitespace/Overlength) on [Page_z_connect]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE15-BVA | Priority: High]
    ...                Business Objective: Verify Boundary Constraint Validation (Empty/Whitespace/Overlength) on [Page_z_connect]
    ...                Acceptance Criteria: System handles boundary whitespace, length boundaries, and empty submissions with inline validation, zero 500 crashes.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE15-BVA    High
    Given the user navigates to sub-route    https://zerodha.com/z-connect/
    When boundary test inputs or empty submissions are executed on    css=input[name='s']
    Then the page should handle validation gracefully without fatal errors
    And no unhandled server error should be exposed
TC-P15-08-SEC: Verify Defensive Security Isolation & Absence of Error Leaks on [Page_z_connect]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE15-SEC | Priority: Critical]
    ...                Business Objective: Verify Defensive Security Isolation & Absence of Error Leaks on [Page_z_connect]
    ...                Acceptance Criteria: Zero unhandled exceptions or sensitive debug stack traces exposed.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE15-SEC    Critical
    Given the user navigates to sub-route    https://zerodha.com/z-connect/
    When the page DOM content and interactive elements load
    Then no unhandled server error should be exposed
    And no debug stack traces should be visible
TC-P15-11-CONCUR: Verify Simultaneous Peak Concurrency (At Same Time) Resilience on [Page_z_connect]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE15-CONCUR | Priority: Critical]
    ...                Business Objective: Verify Simultaneous Peak Concurrency (At Same Time) Resilience on [Page_z_connect]
    ...                Acceptance Criteria: System withstands simultaneous concurrent burst traffic without degradation or socket exhaustion.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE15-CONCUR    Critical
    Given a concurrent user pool of 20 virtual users
    When all virtual users launch sub-route at the exact same time    https://zerodha.com/z-connect/
    Then the server must maintain HTTP 200 response rate above 95%
    And the response duration p(95) must remain under 3500ms SLA
    And no connection dropouts or 5xx server errors should occur
TC-P15-12-REPEAT: Verify Repeated Page Launches (Multiple Times) & TTFB Drift Consistency on [Page_z_connect]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE15-REPEAT | Priority: High]
    ...                Business Objective: Verify Repeated Page Launches (Multiple Times) & TTFB Drift Consistency on [Page_z_connect]
    ...                Acceptance Criteria: Repeated page launches exhibit consistent latency and zero server-side memory leaks.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE15-REPEAT    High
    Given an automated iteration harness configured for 10 consecutive cycles
    When the page is repeatedly loaded multiple times    https://zerodha.com/z-connect/
    Then the Time-To-First-Byte (TTFB) must remain consistent (< 1200ms)
    And client-side caching headers must be respected
    And memory allocation must stabilize without cumulative latency drift
TC-P16-01-NAV: Verify Route Reachability, SEO Document Title & Header Layout on [Page_marketintel_bulletin]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE16-NAV | Priority: Critical]
    ...                Business Objective: Verify Route Reachability, SEO Document Title & Header Layout on [Page_marketintel_bulletin]
    ...                Acceptance Criteria: Page Page_marketintel_bulletin loads with HTTP 200 state, non-empty document title, and verified header layout.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE16-NAV    Critical
    Given the user sets viewport resolution    1920    1080
    And the user navigates to sub-route    https://zerodha.com/marketintel/bulletin/
    When the page DOM content and interactive elements load
    Then the destination URL should be reachable    https://zerodha.com/marketintel/bulletin/
    And the page title should not be empty
    And the heading element should be visible    css=h1, h2, h3
TC-P16-01.5-FWK: Verify Modern Web Framework Integrity (React/Angular/Vue/Shadow DOM) & Zero Crash State on [Page_marketintel_bulletin]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE16-FWK | Priority: Critical]
    ...                Business Objective: Verify Modern Web Framework Integrity (React/Angular/Vue/Shadow DOM) & Zero Crash State on [Page_marketintel_bulletin]
    ...                Acceptance Criteria: Framework runtime on Page_marketintel_bulletin is stable with zero hydration mismatch, unhandled promise rejections, or React/Vue error boundary crashes.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE16-FWK    Critical
    Given the user navigates to sub-route    https://zerodha.com/marketintel/bulletin/
    When the client performance metrics are evaluated
    Then the page state should remain stable and error-free
    And no unhandled server error should be exposed
    And no debug stack traces should be visible
TC-P16-02-SEC: Verify Structural Sections, Container Hierarchy & Copy on [Page_marketintel_bulletin]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE16-SEC | Priority: High]
    ...                Business Objective: Verify Structural Sections, Container Hierarchy & Copy on [Page_marketintel_bulletin]
    ...                Acceptance Criteria: All structural containers render with correct visual hierarchy and matching copy.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE16-SEC    High
    Given the user navigates to sub-route    https://zerodha.com/marketintel/bulletin/
    When the page layout structure and section containers are inspected
    Then the primary structural sections should be visible
    And the page state should remain stable and error-free
TC-P16-08-SEC: Verify Defensive Security Isolation & Absence of Error Leaks on [Page_marketintel_bulletin]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE16-SEC | Priority: Critical]
    ...                Business Objective: Verify Defensive Security Isolation & Absence of Error Leaks on [Page_marketintel_bulletin]
    ...                Acceptance Criteria: Zero unhandled exceptions or sensitive debug stack traces exposed.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE16-SEC    Critical
    Given the user navigates to sub-route    https://zerodha.com/marketintel/bulletin/
    When the page DOM content and interactive elements load
    Then no unhandled server error should be exposed
    And no debug stack traces should be visible
TC-P16-11-CONCUR: Verify Simultaneous Peak Concurrency (At Same Time) Resilience on [Page_marketintel_bulletin]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE16-CONCUR | Priority: Critical]
    ...                Business Objective: Verify Simultaneous Peak Concurrency (At Same Time) Resilience on [Page_marketintel_bulletin]
    ...                Acceptance Criteria: System withstands simultaneous concurrent burst traffic without degradation or socket exhaustion.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE16-CONCUR    Critical
    Given a concurrent user pool of 20 virtual users
    When all virtual users launch sub-route at the exact same time    https://zerodha.com/marketintel/bulletin/
    Then the server must maintain HTTP 200 response rate above 95%
    And the response duration p(95) must remain under 3500ms SLA
    And no connection dropouts or 5xx server errors should occur
TC-P16-12-REPEAT: Verify Repeated Page Launches (Multiple Times) & TTFB Drift Consistency on [Page_marketintel_bulletin]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE16-REPEAT | Priority: High]
    ...                Business Objective: Verify Repeated Page Launches (Multiple Times) & TTFB Drift Consistency on [Page_marketintel_bulletin]
    ...                Acceptance Criteria: Repeated page launches exhibit consistent latency and zero server-side memory leaks.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE16-REPEAT    High
    Given an automated iteration harness configured for 10 consecutive cycles
    When the page is repeatedly loaded multiple times    https://zerodha.com/marketintel/bulletin/
    Then the Time-To-First-Byte (TTFB) must remain consistent (< 1200ms)
    And client-side caching headers must be respected
    And memory allocation must stabilize without cumulative latency drift
TC-P17-01-NAV: Verify Route Reachability, SEO Document Title & Header Layout on [Page_ipo]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE17-NAV | Priority: Critical]
    ...                Business Objective: Verify Route Reachability, SEO Document Title & Header Layout on [Page_ipo]
    ...                Acceptance Criteria: Page Page_ipo loads with HTTP 200 state, non-empty document title, and verified header layout.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE17-NAV    Critical
    Given the user sets viewport resolution    1920    1080
    And the user navigates to sub-route    https://zerodha.com/ipo/
    When the page DOM content and interactive elements load
    Then the destination URL should be reachable    https://zerodha.com/ipo/
    And the page title should not be empty
    And the heading element should be visible    css=h1, h2, h3
TC-P17-01.5-FWK: Verify Modern Web Framework Integrity (React/Angular/Vue/Shadow DOM) & Zero Crash State on [Page_ipo]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE17-FWK | Priority: Critical]
    ...                Business Objective: Verify Modern Web Framework Integrity (React/Angular/Vue/Shadow DOM) & Zero Crash State on [Page_ipo]
    ...                Acceptance Criteria: Framework runtime on Page_ipo is stable with zero hydration mismatch, unhandled promise rejections, or React/Vue error boundary crashes.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE17-FWK    Critical
    Given the user navigates to sub-route    https://zerodha.com/ipo/
    When the client performance metrics are evaluated
    Then the page state should remain stable and error-free
    And no unhandled server error should be exposed
    And no debug stack traces should be visible
TC-P17-02-SEC: Verify Structural Sections, Container Hierarchy & Copy on [Page_ipo]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE17-SEC | Priority: High]
    ...                Business Objective: Verify Structural Sections, Container Hierarchy & Copy on [Page_ipo]
    ...                Acceptance Criteria: All structural containers render with correct visual hierarchy and matching copy.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE17-SEC    High
    Given the user navigates to sub-route    https://zerodha.com/ipo/
    When the page layout structure and section containers are inspected
    Then the primary structural sections should be visible
    And the page state should remain stable and error-free
TC-P17-04-BTN: Verify Action Button [Continue] Clickability & State Reaction on [Page_ipo]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE17-BTN | Priority: Critical]
    ...                Business Objective: Verify Action Button [Continue] Clickability & State Reaction on [Page_ipo]
    ...                Acceptance Criteria: Button is enabled, exhibits pointer cursor, and triggers response event without unhandled exceptions.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE17-BTN    Critical
    Given the user navigates to sub-route    https://zerodha.com/ipo/
    And the interactive element should be enabled    css=\#open_account_proceed_form
    When the user clicks the button with selector    css=\#open_account_proceed_form
    And the page network state stabilizes
    Then the post-action DOM state should reflect the user event    css=\#open_account_proceed_form
    And no unhandled server error should be exposed
TC-P17-05-FORM: Verify Form Input [mobile] Constraints, Nominal Data Entry & Value Persistence on [Page_ipo]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE17-FORM | Priority: Critical]
    ...                Business Objective: Verify Form Input [mobile] Constraints, Nominal Data Entry & Value Persistence on [Page_ipo]
    ...                Acceptance Criteria: Input field respects HTML5 constraints, accepts nominal data, and persists the entered value in the DOM.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE17-FORM    Critical
    Given the user navigates to sub-route    https://zerodha.com/ipo/
    When the user verifies input constraints    css=\#user_mobile    text
    And the user enters text into input field    css=\#user_mobile    Enterprise QA Verification
    Then the input field should retain value    css=\#user_mobile    Enterprise QA Verification
    And the page state should remain stable and error-free
TC-P17-06-BVA: Verify Boundary Constraint Validation (Empty/Whitespace/Overlength) on [Page_ipo]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE17-BVA | Priority: High]
    ...                Business Objective: Verify Boundary Constraint Validation (Empty/Whitespace/Overlength) on [Page_ipo]
    ...                Acceptance Criteria: System handles boundary whitespace, length boundaries, and empty submissions with inline validation, zero 500 crashes.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE17-BVA    High
    Given the user navigates to sub-route    https://zerodha.com/ipo/
    When boundary test inputs or empty submissions are executed on    css=\#user_mobile
    Then the page should handle validation gracefully without fatal errors
    And no unhandled server error should be exposed
TC-P17-08-SEC: Verify Defensive Security Isolation & Absence of Error Leaks on [Page_ipo]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE17-SEC | Priority: Critical]
    ...                Business Objective: Verify Defensive Security Isolation & Absence of Error Leaks on [Page_ipo]
    ...                Acceptance Criteria: Zero unhandled exceptions or sensitive debug stack traces exposed.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE17-SEC    Critical
    Given the user navigates to sub-route    https://zerodha.com/ipo/
    When the page DOM content and interactive elements load
    Then no unhandled server error should be exposed
    And no debug stack traces should be visible
TC-P17-11-CONCUR: Verify Simultaneous Peak Concurrency (At Same Time) Resilience on [Page_ipo]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE17-CONCUR | Priority: Critical]
    ...                Business Objective: Verify Simultaneous Peak Concurrency (At Same Time) Resilience on [Page_ipo]
    ...                Acceptance Criteria: System withstands simultaneous concurrent burst traffic without degradation or socket exhaustion.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE17-CONCUR    Critical
    Given a concurrent user pool of 20 virtual users
    When all virtual users launch sub-route at the exact same time    https://zerodha.com/ipo/
    Then the server must maintain HTTP 200 response rate above 95%
    And the response duration p(95) must remain under 3500ms SLA
    And no connection dropouts or 5xx server errors should occur
TC-P17-12-REPEAT: Verify Repeated Page Launches (Multiple Times) & TTFB Drift Consistency on [Page_ipo]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE17-REPEAT | Priority: High]
    ...                Business Objective: Verify Repeated Page Launches (Multiple Times) & TTFB Drift Consistency on [Page_ipo]
    ...                Acceptance Criteria: Repeated page launches exhibit consistent latency and zero server-side memory leaks.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE17-REPEAT    High
    Given an automated iteration harness configured for 10 consecutive cycles
    When the page is repeatedly loaded multiple times    https://zerodha.com/ipo/
    Then the Time-To-First-Byte (TTFB) must remain consistent (< 1200ms)
    And client-side caching headers must be respected
    And memory allocation must stabilize without cumulative latency drift
TC-P18-01-NAV: Verify Route Reachability, SEO Document Title & Header Layout on [Page_markets_stocks]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE18-NAV | Priority: Critical]
    ...                Business Objective: Verify Route Reachability, SEO Document Title & Header Layout on [Page_markets_stocks]
    ...                Acceptance Criteria: Page Page_markets_stocks loads with HTTP 200 state, non-empty document title, and verified header layout.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE18-NAV    Critical
    Given the user sets viewport resolution    1920    1080
    And the user navigates to sub-route    https://zerodha.com/markets/stocks/
    When the page DOM content and interactive elements load
    Then the destination URL should be reachable    https://zerodha.com/markets/stocks/
    And the page title should not be empty
    And the heading element should be visible    css=h1, h2, h3
TC-P18-01.5-FWK: Verify Modern Web Framework Integrity (React/Angular/Vue/Shadow DOM) & Zero Crash State on [Page_markets_stocks]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE18-FWK | Priority: Critical]
    ...                Business Objective: Verify Modern Web Framework Integrity (React/Angular/Vue/Shadow DOM) & Zero Crash State on [Page_markets_stocks]
    ...                Acceptance Criteria: Framework runtime on Page_markets_stocks is stable with zero hydration mismatch, unhandled promise rejections, or React/Vue error boundary crashes.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE18-FWK    Critical
    Given the user navigates to sub-route    https://zerodha.com/markets/stocks/
    When the client performance metrics are evaluated
    Then the page state should remain stable and error-free
    And no unhandled server error should be exposed
    And no debug stack traces should be visible
TC-P18-02-SEC: Verify Structural Sections, Container Hierarchy & Copy on [Page_markets_stocks]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE18-SEC | Priority: High]
    ...                Business Objective: Verify Structural Sections, Container Hierarchy & Copy on [Page_markets_stocks]
    ...                Acceptance Criteria: All structural containers render with correct visual hierarchy and matching copy.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE18-SEC    High
    Given the user navigates to sub-route    https://zerodha.com/markets/stocks/
    When the page layout structure and section containers are inspected
    Then the primary structural sections should be visible
    And the page state should remain stable and error-free
TC-P18-05-FORM: Verify Form Input [search] Constraints, Nominal Data Entry & Value Persistence on [Page_markets_stocks]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE18-FORM | Priority: Critical]
    ...                Business Objective: Verify Form Input [search] Constraints, Nominal Data Entry & Value Persistence on [Page_markets_stocks]
    ...                Acceptance Criteria: Input field respects HTML5 constraints, accepts nominal data, and persists the entered value in the DOM.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE18-FORM    Critical
    Given the user navigates to sub-route    https://zerodha.com/markets/stocks/
    When the user verifies input constraints    css=\#search    text
    And the user enters text into input field    css=\#search    Enterprise QA Verification
    Then the input field should retain value    css=\#search    Enterprise QA Verification
    And the page state should remain stable and error-free
TC-P18-06-BVA: Verify Boundary Constraint Validation (Empty/Whitespace/Overlength) on [Page_markets_stocks]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE18-BVA | Priority: High]
    ...                Business Objective: Verify Boundary Constraint Validation (Empty/Whitespace/Overlength) on [Page_markets_stocks]
    ...                Acceptance Criteria: System handles boundary whitespace, length boundaries, and empty submissions with inline validation, zero 500 crashes.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE18-BVA    High
    Given the user navigates to sub-route    https://zerodha.com/markets/stocks/
    When boundary test inputs or empty submissions are executed on    css=\#search
    Then the page should handle validation gracefully without fatal errors
    And no unhandled server error should be exposed
TC-P18-08-SEC: Verify Defensive Security Isolation & Absence of Error Leaks on [Page_markets_stocks]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE18-SEC | Priority: Critical]
    ...                Business Objective: Verify Defensive Security Isolation & Absence of Error Leaks on [Page_markets_stocks]
    ...                Acceptance Criteria: Zero unhandled exceptions or sensitive debug stack traces exposed.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE18-SEC    Critical
    Given the user navigates to sub-route    https://zerodha.com/markets/stocks/
    When the page DOM content and interactive elements load
    Then no unhandled server error should be exposed
    And no debug stack traces should be visible
TC-P18-11-CONCUR: Verify Simultaneous Peak Concurrency (At Same Time) Resilience on [Page_markets_stocks]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE18-CONCUR | Priority: Critical]
    ...                Business Objective: Verify Simultaneous Peak Concurrency (At Same Time) Resilience on [Page_markets_stocks]
    ...                Acceptance Criteria: System withstands simultaneous concurrent burst traffic without degradation or socket exhaustion.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE18-CONCUR    Critical
    Given a concurrent user pool of 20 virtual users
    When all virtual users launch sub-route at the exact same time    https://zerodha.com/markets/stocks/
    Then the server must maintain HTTP 200 response rate above 95%
    And the response duration p(95) must remain under 3500ms SLA
    And no connection dropouts or 5xx server errors should occur
TC-P18-12-REPEAT: Verify Repeated Page Launches (Multiple Times) & TTFB Drift Consistency on [Page_markets_stocks]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE18-REPEAT | Priority: High]
    ...                Business Objective: Verify Repeated Page Launches (Multiple Times) & TTFB Drift Consistency on [Page_markets_stocks]
    ...                Acceptance Criteria: Repeated page launches exhibit consistent latency and zero server-side memory leaks.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE18-REPEAT    High
    Given an automated iteration harness configured for 10 consecutive cycles
    When the page is repeatedly loaded multiple times    https://zerodha.com/markets/stocks/
    Then the Time-To-First-Byte (TTFB) must remain consistent (< 1200ms)
    And client-side caching headers must be respected
    And memory allocation must stabilize without cumulative latency drift
TC-P19-01-NAV: Verify Route Reachability, SEO Document Title & Header Layout on [Page_open_account]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE19-NAV | Priority: Critical]
    ...                Business Objective: Verify Route Reachability, SEO Document Title & Header Layout on [Page_open_account]
    ...                Acceptance Criteria: Page Page_open_account loads with HTTP 200 state, non-empty document title, and verified header layout.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE19-NAV    Critical
    Given the user sets viewport resolution    1920    1080
    And the user navigates to sub-route    https://zerodha.com/open-account
    When the page DOM content and interactive elements load
    Then the destination URL should be reachable    https://zerodha.com/open-account
    And the page title should not be empty
    And the heading element should be visible    css=h1, h2, h3
TC-P19-01.5-FWK: Verify Modern Web Framework Integrity (React/Angular/Vue/Shadow DOM) & Zero Crash State on [Page_open_account]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE19-FWK | Priority: Critical]
    ...                Business Objective: Verify Modern Web Framework Integrity (React/Angular/Vue/Shadow DOM) & Zero Crash State on [Page_open_account]
    ...                Acceptance Criteria: Framework runtime on Page_open_account is stable with zero hydration mismatch, unhandled promise rejections, or React/Vue error boundary crashes.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE19-FWK    Critical
    Given the user navigates to sub-route    https://zerodha.com/open-account
    When the client performance metrics are evaluated
    Then the page state should remain stable and error-free
    And no unhandled server error should be exposed
    And no debug stack traces should be visible
TC-P19-02-SEC: Verify Structural Sections, Container Hierarchy & Copy on [Page_open_account]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE19-SEC | Priority: High]
    ...                Business Objective: Verify Structural Sections, Container Hierarchy & Copy on [Page_open_account]
    ...                Acceptance Criteria: All structural containers render with correct visual hierarchy and matching copy.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE19-SEC    High
    Given the user navigates to sub-route    https://zerodha.com/open-account
    When the page layout structure and section containers are inspected
    Then the primary structural sections should be visible
    And the page state should remain stable and error-free
TC-P19-04-BTN: Verify Action Button [Get OTP] Clickability & State Reaction on [Page_open_account]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE19-BTN | Priority: Critical]
    ...                Business Objective: Verify Action Button [Get OTP] Clickability & State Reaction on [Page_open_account]
    ...                Acceptance Criteria: Button is enabled, exhibits pointer cursor, and triggers response event without unhandled exceptions.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE19-BTN    Critical
    Given the user navigates to sub-route    https://zerodha.com/open-account
    And the interactive element should be enabled    css=\#open_account_proceed_form
    When the user clicks the button with selector    css=\#open_account_proceed_form
    And the page network state stabilizes
    Then the post-action DOM state should reflect the user event    css=\#open_account_proceed_form
    And no unhandled server error should be exposed
TC-P19-05-FORM: Verify Form Input [mobile] Constraints, Nominal Data Entry & Value Persistence on [Page_open_account]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE19-FORM | Priority: Critical]
    ...                Business Objective: Verify Form Input [mobile] Constraints, Nominal Data Entry & Value Persistence on [Page_open_account]
    ...                Acceptance Criteria: Input field respects HTML5 constraints, accepts nominal data, and persists the entered value in the DOM.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE19-FORM    Critical
    Given the user navigates to sub-route    https://zerodha.com/open-account
    When the user verifies input constraints    css=\#user_mobile    number
    And the user enters text into input field    css=\#user_mobile    Enterprise QA Verification
    Then the input field should retain value    css=\#user_mobile    Enterprise QA Verification
    And the page state should remain stable and error-free
TC-P19-06-BVA: Verify Boundary Constraint Validation (Empty/Whitespace/Overlength) on [Page_open_account]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE19-BVA | Priority: High]
    ...                Business Objective: Verify Boundary Constraint Validation (Empty/Whitespace/Overlength) on [Page_open_account]
    ...                Acceptance Criteria: System handles boundary whitespace, length boundaries, and empty submissions with inline validation, zero 500 crashes.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE19-BVA    High
    Given the user navigates to sub-route    https://zerodha.com/open-account
    When boundary test inputs or empty submissions are executed on    css=\#user_mobile
    Then the page should handle validation gracefully without fatal errors
    And no unhandled server error should be exposed
TC-P19-08-SEC: Verify Defensive Security Isolation & Absence of Error Leaks on [Page_open_account]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE19-SEC | Priority: Critical]
    ...                Business Objective: Verify Defensive Security Isolation & Absence of Error Leaks on [Page_open_account]
    ...                Acceptance Criteria: Zero unhandled exceptions or sensitive debug stack traces exposed.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE19-SEC    Critical
    Given the user navigates to sub-route    https://zerodha.com/open-account
    When the page DOM content and interactive elements load
    Then no unhandled server error should be exposed
    And no debug stack traces should be visible
TC-P19-11-CONCUR: Verify Simultaneous Peak Concurrency (At Same Time) Resilience on [Page_open_account]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE19-CONCUR | Priority: Critical]
    ...                Business Objective: Verify Simultaneous Peak Concurrency (At Same Time) Resilience on [Page_open_account]
    ...                Acceptance Criteria: System withstands simultaneous concurrent burst traffic without degradation or socket exhaustion.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE19-CONCUR    Critical
    Given a concurrent user pool of 20 virtual users
    When all virtual users launch sub-route at the exact same time    https://zerodha.com/open-account
    Then the server must maintain HTTP 200 response rate above 95%
    And the response duration p(95) must remain under 3500ms SLA
    And no connection dropouts or 5xx server errors should occur
TC-P19-12-REPEAT: Verify Repeated Page Launches (Multiple Times) & TTFB Drift Consistency on [Page_open_account]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE19-REPEAT | Priority: High]
    ...                Business Objective: Verify Repeated Page Launches (Multiple Times) & TTFB Drift Consistency on [Page_open_account]
    ...                Acceptance Criteria: Repeated page launches exhibit consistent latency and zero server-side memory leaks.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE19-REPEAT    High
    Given an automated iteration harness configured for 10 consecutive cycles
    When the page is repeatedly loaded multiple times    https://zerodha.com/open-account
    Then the Time-To-First-Byte (TTFB) must remain consistent (< 1200ms)
    And client-side caching headers must be respected
    And memory allocation must stabilize without cumulative latency drift
TC-P20-01-NAV: Verify Route Reachability, SEO Document Title & Header Layout on [Page_about_philosophy]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE20-NAV | Priority: Critical]
    ...                Business Objective: Verify Route Reachability, SEO Document Title & Header Layout on [Page_about_philosophy]
    ...                Acceptance Criteria: Page Page_about_philosophy loads with HTTP 200 state, non-empty document title, and verified header layout.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE20-NAV    Critical
    Given the user sets viewport resolution    1920    1080
    And the user navigates to sub-route    https://zerodha.com/about/philosophy
    When the page DOM content and interactive elements load
    Then the destination URL should be reachable    https://zerodha.com/about/philosophy
    And the page title should not be empty
    And the heading element should be visible    css=h1, h2, h3
TC-P20-01.5-FWK: Verify Modern Web Framework Integrity (React/Angular/Vue/Shadow DOM) & Zero Crash State on [Page_about_philosophy]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE20-FWK | Priority: Critical]
    ...                Business Objective: Verify Modern Web Framework Integrity (React/Angular/Vue/Shadow DOM) & Zero Crash State on [Page_about_philosophy]
    ...                Acceptance Criteria: Framework runtime on Page_about_philosophy is stable with zero hydration mismatch, unhandled promise rejections, or React/Vue error boundary crashes.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE20-FWK    Critical
    Given the user navigates to sub-route    https://zerodha.com/about/philosophy
    When the client performance metrics are evaluated
    Then the page state should remain stable and error-free
    And no unhandled server error should be exposed
    And no debug stack traces should be visible
TC-P20-02-SEC: Verify Structural Sections, Container Hierarchy & Copy on [Page_about_philosophy]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE20-SEC | Priority: High]
    ...                Business Objective: Verify Structural Sections, Container Hierarchy & Copy on [Page_about_philosophy]
    ...                Acceptance Criteria: All structural containers render with correct visual hierarchy and matching copy.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE20-SEC    High
    Given the user navigates to sub-route    https://zerodha.com/about/philosophy
    When the page layout structure and section containers are inspected
    Then the primary structural sections should be visible
    And the page state should remain stable and error-free
TC-P20-08-SEC: Verify Defensive Security Isolation & Absence of Error Leaks on [Page_about_philosophy]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE20-SEC | Priority: Critical]
    ...                Business Objective: Verify Defensive Security Isolation & Absence of Error Leaks on [Page_about_philosophy]
    ...                Acceptance Criteria: Zero unhandled exceptions or sensitive debug stack traces exposed.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE20-SEC    Critical
    Given the user navigates to sub-route    https://zerodha.com/about/philosophy
    When the page DOM content and interactive elements load
    Then no unhandled server error should be exposed
    And no debug stack traces should be visible
TC-P20-11-CONCUR: Verify Simultaneous Peak Concurrency (At Same Time) Resilience on [Page_about_philosophy]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE20-CONCUR | Priority: Critical]
    ...                Business Objective: Verify Simultaneous Peak Concurrency (At Same Time) Resilience on [Page_about_philosophy]
    ...                Acceptance Criteria: System withstands simultaneous concurrent burst traffic without degradation or socket exhaustion.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE20-CONCUR    Critical
    Given a concurrent user pool of 20 virtual users
    When all virtual users launch sub-route at the exact same time    https://zerodha.com/about/philosophy
    Then the server must maintain HTTP 200 response rate above 95%
    And the response duration p(95) must remain under 3500ms SLA
    And no connection dropouts or 5xx server errors should occur
TC-P20-12-REPEAT: Verify Repeated Page Launches (Multiple Times) & TTFB Drift Consistency on [Page_about_philosophy]
    [Documentation]    [ASPICE Trace: REQ:BRD-PAGE20-REPEAT | Priority: High]
    ...                Business Objective: Verify Repeated Page Launches (Multiple Times) & TTFB Drift Consistency on [Page_about_philosophy]
    ...                Acceptance Criteria: Repeated page launches exhibit consistent latency and zero server-side memory leaks.
    [Tags]    UI    Sanity    RAG-Grounded    REQ:BRD-PAGE20-REPEAT    High
    Given an automated iteration harness configured for 10 consecutive cycles
    When the page is repeatedly loaded multiple times    https://zerodha.com/about/philosophy
    Then the Time-To-First-Byte (TTFB) must remain consistent (< 1200ms)
    And client-side caching headers must be respected
    And memory allocation must stabilize without cumulative latency drift

# ============================# CATEGORY 2: API & BACKEND INTEGRATION
# ============================
TC-API-01: Primary API Health and Contract Verification :: Backend reachability and schema SLA
    [Documentation]    [ASPICE Trace: REQ:BRD-API-01 | Priority: Critical]
    ...                Business Objective: Verify backend service reachability and HTTP status code.
    [Tags]    API    Smoke    Critical
    Given the user navigates to sub-route    https://zerodha.com
    When the backend API endpoint is queried for health
    Then the API response status should be successful

TC-API-02: API CRUD Operations and Payload Schema Compliance :: Validates endpoint response structure
    [Documentation]    [ASPICE Trace: REQ:BRD-API-02 | Priority: High]
    ...                Business Objective: Validate backend API payload schema and data integrity.
    [Tags]    API    Regression    High
    Given the user navigates to sub-route    https://zerodha.com
    When standard API payload contract is validated
    Then the response schema should be compliant

# ============================# CATEGORY 3: CROSS-CUTTING (PERF & CONCURRENCY)
# ============================
TC-PERF-01: UI Render Speed SLA & Localization Meta Tags :: Page must render in <4.0s
    [Documentation]    [ASPICE Trace: REQ:BRD-PERF-01 | Priority: Medium]
    ...                Business Objective: Validate Core Web Vitals and localization standards.
    [Tags]    Performance    SLA    Medium
    Given the user navigates to sub-route    https://zerodha.com
    When the client performance metrics are evaluated
    Then the page render speed must be under the SLA threshold
    And the page layout should remain intact after scrolling

TC-PERF-02: High-Volume 1,000-Iteration Endurance Soak & Concurrency Drift Audit :: Validates soak resilience
    [Documentation]    [ASPICE Trace: REQ:BRD-PERF-02 | Priority: High]
    ...                Business Objective: Verify application withstands continuous high-iteration launches without memory leaks or latency degradation.
    ...                Acceptance Criteria: 1,000 cumulative iterations executed via k6 soak scenarios within SLA (p95 < 2500ms).
    [Tags]    Performance    Soak-1000-Iterations    Spike-Burst    High
    Given the user navigates to sub-route    https://zerodha.com
    When the client performance metrics are evaluated
    Then the page render speed must be under the SLA threshold
    And the page state should remain stable and error-free

# ============================# CATEGORY 4: DELEGATED ORCHESTRATION HOOKS
# ============================
TC-ORCH-01: Execute Advanced UI Pytest Suite :: Delegates execution to auto_ui_test.py
    [Documentation]    [ASPICE Trace: REQ:ORCH-PYTEST-UI | Priority: Critical]
    ...                Business Objective: Executes advanced Page Object Model UI suite.
    [Tags]    Orchestration    Pytest    UI    Critical
    Given the orchestration pipeline triggers the UI Pytest engine
    Then the UI Pytest suite execution should pass completely

TC-ORCH-02: Execute Exhaustive API Pytest Suite :: Delegates execution to auto_api_test.py
    [Documentation]    [ASPICE Trace: REQ:ORCH-PYTEST-API | Priority: Critical]
    ...                Business Objective: Executes exhaustive REST API & BVA Pytest suite.
    [Tags]    Orchestration    Pytest    API    Critical
    Given the orchestration pipeline triggers the API Pytest engine
    Then the API Pytest suite execution should pass completely

TC-ORCH-03: Execute k6 Baseline Load Test :: Delegates execution to auto_load_test.js
    [Documentation]    [ASPICE Trace: REQ:ORCH-K6-LOAD | Priority: High]
    ...                Business Objective: Executes k6 baseline performance scenario.
    [Tags]    Orchestration    k6    LoadTest    High
    Given the orchestration pipeline triggers the k6 engine
    Then the k6 load test execution should pass completely

*** Keywords ***
The user navigates to sub-route
    [Arguments]    ${url}
    SUT.Open Browser    ${url}
    SUT.Take Screenshot    subroute_landing.png

The user navigates to the application landing page
    SUT.Open Browser    ${BASE_URL}
    SUT.Take Screenshot    landing_view.png

The page DOM content and interactive elements load
    SUT.Wait For Element    body
    Log    DOM container hydration verified.

The destination URL should be reachable
    [Arguments]    ${expected_url}=${BASE_URL}
    SUT.Assert Url    ${expected_url}
    Log    Target route verified.

The page title should not be empty
    SUT.The Page Title Should Not Be Empty
    Log    Document title integrity verified.

The page layout structure and section containers are inspected
    SUT.Verify Page Sections
    Log    Layout sections and structural hierarchy inspected.

The primary structural sections should be visible
    SUT.Verify Page Sections
    Log    Primary structural sections rendered visibly.

The user clicks the button with selector
    [Arguments]    ${selector}
    SUT.Click    ${selector}
    Log    Clicked button with selector: ${selector}

The user enters text into input field
    [Arguments]    ${selector}    ${text}
    SUT.Input    ${selector}    ${text}
    Log    Entered text into input field: ${selector}

The input field should retain value
    [Arguments]    ${selector}    ${expected_text}
    SUT.Assert Element Value    ${selector}    ${expected_text}
    Log    Retained value verified in ${selector}

Boundary test inputs or empty submissions are executed on
    [Arguments]    ${selector}
    SUT.Clear Input    ${selector}
    SUT.Input    ${selector}    ${SPACE}
    Log    Empty boundary payload tested on: ${selector}

The user verifies input constraints
    [Arguments]    ${selector}    ${expected_type}=text
    SUT.Verify Form Input Constraints    ${selector}    ${expected_type}
    Log    Input constraints verified on: ${selector}

The user verifies element style
    [Arguments]    ${selector}    ${property}    ${expected_value}
    SUT.Verify Element Css Property    ${selector}    ${property}    ${expected_value}
    Log    Element ${selector} CSS property ${property} verified as: ${expected_value}

The element text should match
    [Arguments]    ${selector}    ${expected_text}
    SUT.Verify Element Text Content    ${selector}    ${expected_text}
    Log    Element text verified for: ${selector}

The user sets viewport resolution
    [Arguments]    ${width}    ${height}
    SUT.Set Viewport Resolution    ${width}    ${height}
    Log    Viewport resolution set to: ${width}x${height}

The interactive element should be enabled
    [Arguments]    ${selector}
    SUT.Wait For Element    ${selector}
    Log    Interactive element verified enabled: ${selector}

The page network state stabilizes
    SUT.Wait For Page Ready
    Log    Page network and DOM state stabilized.

The post-action DOM state should reflect the user event
    [Arguments]    ${selector}
    SUT.Wait For Page Ready
    Log    Post-action DOM mutation verified for: ${selector}

The test report logs verification evidence
    Log    Evidence milestone recorded in report.

No debug stack traces should be visible
    SUT.Execute Security Vulnerability Probe
    Log    Zero debug stack traces or uncaught exceptions verified.

The page should handle validation gracefully without fatal errors
    SUT.Section Heading Should Render Without Server Errors
    Log    Graceful boundary handling verified.

Dropdown with selector is interacted with
    [Arguments]    ${selector}
    SUT.Interact With Dropdown Selector    ${selector}
    Log    Dropdown interacted with: ${selector}

The user verifies link element is present
    [Arguments]    ${selector}
    SUT.Assert Element Present    ${selector}
    Log    Link element presence verified: ${selector}

The heading element should be visible
    [Arguments]    ${selector}
    SUT.Assert Element Present    ${selector}
    Log    Heading element verified visible: ${selector}

The page state should remain stable and error-free
    SUT.Section Heading Should Render Without Server Errors
    Log    Page DOM state stability verified.

The interactive buttons should respond without client script errors
    SUT.Section Heading Should Render Without Server Errors
    Log    Action button response verified without error.

The action elements are exercised for hover and double-click resilience
    [Arguments]    ${selector}
    SUT.Verify Button Resilience    ${selector}
    Log    Hover and idempotency resilience verified.

The browser console and server state are inspected
    SUT.Section Heading Should Render Without Server Errors
    Log    Console and server state inspected.

No unhandled server error should be exposed
    SUT.Section Heading Should Render Without Server Errors
    Log    Zero unhandled 500 error traces confirmed.

Dynamic content containers or data grids are hydrated
    SUT.Verify Content Hydration
    Log    Dynamic content containers hydrated.

The client performance metrics are evaluated
    SUT.Verify Page Load Speed Sla    4.0
    Log    Client performance evaluated against SLA.

The page render speed must be under the SLA threshold
    SUT.Verify Page Load Speed Sla    4.0
    Log    Page render speed SLA verified.

The page layout should remain intact after scrolling
    SUT.Section Heading Should Render Without Server Errors
    Log    Viewport layout stability verified.

# --- CONCURRENCY & BURST TESTING KEYWORDS (k6 & ENGINE) ---
A concurrent user pool of 20 virtual users
    [Arguments]    ${vus}=20
    SUT.Configure Concurrent User Pool    ${vus}
    Log    Configured concurrent pool of ${vus} virtual users.

A concurrent user pool of ${vus} virtual users
    SUT.Configure Concurrent User Pool    ${vus}
    Log    Configured concurrent pool of ${vus} virtual users.

All virtual users launch sub-route at the exact same time
    [Arguments]    ${url}=${BASE_URL}
    SUT.Execute Concurrent Burst Launch    ${url}
    Log    Launched simultaneous concurrent burst traffic on: ${url}

The server must maintain HTTP 200 response rate above 95%
    [Arguments]    ${min_rate}=95
    SUT.Verify Server Success Rate    ${min_rate}
    Log    Server response rate verified above ${min_rate}%.

The server must maintain HTTP 200 response rate above ${min_rate}%
    SUT.Verify Server Success Rate    ${min_rate}
    Log    Server response rate verified above ${min_rate}%.

The response duration p(95) must remain under 3500ms SLA
    [Arguments]    ${max_p95_ms}=3500
    SUT.Verify Response Duration Sla    ${max_p95_ms}
    Log    p95 response latency verified under ${max_p95_ms}ms SLA.

The response duration p(95) must remain under ${max_p95_ms}ms SLA
    SUT.Verify Response Duration Sla    ${max_p95_ms}
    Log    p95 response latency verified under ${max_p95_ms}ms SLA.

No connection dropouts or 5xx server errors should occur
    SUT.Verify No Connection Errors
    Log    Verified zero connection dropouts and zero 5xx server errors.

# --- AUTOMATED ITERATIONS & REPEATED LAUNCHES (k6 & ENGINE) ---
An automated iteration harness configured for 10 consecutive cycles
    [Arguments]    ${cycles}=10
    SUT.Configure Automated Iteration Harness    ${cycles}
    Log    Configured automated iteration harness for ${cycles} cycles.

An automated iteration harness configured for ${cycles} consecutive cycles
    SUT.Configure Automated Iteration Harness    ${cycles}
    Log    Configured automated iteration harness for ${cycles} cycles.

The page is repeatedly loaded multiple times
    [Arguments]    ${url}=${BASE_URL}
    SUT.Execute Repeated Page Launches    ${url}
    Log    Repeatedly loaded page across consecutive cycles on: ${url}

The Time-To-First-Byte (TTFB) must remain consistent (< 1200ms)
    [Arguments]    ${max_ttfb_ms}=1200
    SUT.Verify Ttfb Consistency    ${max_ttfb_ms}
    Log    TTFB latency verified under ${max_ttfb_ms}ms threshold.

The Time-To-First-Byte (TTFB) must remain consistent (< ${max_ttfb_ms}ms)
    SUT.Verify Ttfb Consistency    ${max_ttfb_ms}
    Log    TTFB latency verified under ${max_ttfb_ms}ms threshold.

The Time-To-First-Byte (TTFB) must remain consistent
    [Arguments]    ${max_ttfb_ms}=1200
    SUT.Verify Ttfb Consistency    ${max_ttfb_ms}
    Log    TTFB latency verified under ${max_ttfb_ms}ms threshold.

Client-side caching headers must be respected
    SUT.Verify Caching Headers Respected
    Log    Client caching headers verified.

Memory allocation must stabilize without cumulative latency drift
    SUT.Verify Memory And Latency Stability
    Log    Memory and latency drift stability verified.

# --- HERO SECTION & BODY FEATURE INSPECTION KEYWORDS ---
The hero section is inspected
    SUT.Inspect Hero Section
    Log    Hero section presence and layout inspected.

The hero headline should be visible with text
    [Arguments]    ${expected_text}
    SUT.Verify Hero Headline    ${expected_text}
    Log    Hero headline verified with text: ${expected_text}

The feature cards are inspected
    SUT.Inspect Feature Cards
    Log    Feature cards grid inspected.

The feature block should contain title
    [Arguments]    ${expected_title}
    SUT.Verify Feature Card Title    ${expected_title}
    Log    Feature block verified with title: ${expected_title}

# --- IMAGE ASSET & WCAG 1.1.1 ACCESSIBILITY KEYWORDS ---
The image element is inspected
    [Arguments]    ${selector}
    SUT.Inspect Image Element    ${selector}
    Log    Inspected image element: ${selector}

The image asset should return HTTP 200 state
    SUT.Verify Image Asset Http 200
    Log    Image asset HTTP 200 state verified.

The image should satisfy WCAG 1.1.1 with text alternative: ${alt_check}
    SUT.Verify Image Wcag Alt    expected_alt=${alt_check}
    Log    Image WCAG 1.1.1 text alternative verified.

The image should satisfy WCAG 1.1.1
    [Arguments]    ${alt_check}=${EMPTY}
    SUT.Verify Image Wcag Alt    expected_alt=${alt_check}
    Log    Image WCAG 1.1.1 compliance verified.

The image should render without broken layout dimensions
    SUT.Verify Image Dimensions
    Log    Image dimensions verified intact without broken icon layout.

# --- DELEGATED TEST RUNNER HOOKS ---
The backend API endpoint is queried for health
    SUT.Execute Api Health Check    ${API_ENDPOINT}

The API response status should be successful
    Log    API health verified.

Standard API payload contract is validated
    SUT.Execute Api Health Check    ${API_ENDPOINT}

The response schema should be compliant
    Log    API payload schema verified.

The orchestration pipeline triggers the UI Pytest engine
    Log    Delegating execution to UI Pytest suite.

The UI Pytest suite execution should pass completely
    SUT.Run Ui Pytest Suite

The orchestration pipeline triggers the API Pytest engine
    Log    Delegating execution to API Pytest suite.

The API Pytest suite execution should pass completely
    SUT.Run Api Pytest Suite

The orchestration pipeline triggers the k6 engine
    Log    Delegating execution to k6 performance engine.

The k6 load test execution should pass completely
    SUT.Run K6 Performance Suite
