import http from 'k6/http';
import { sleep } from 'k6';
export const options = { vus: 1, duration: '2s' };
export default function () {
    http.get('https://zerodha.com');
    sleep(0.5);
}
