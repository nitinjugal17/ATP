import xml.etree.ElementTree as ET
import csv, os
def generate_rtm_matrix(xml_path="artifacts/reports/output.xml", out_path="artifacts/reports/Live_RTM_Matrix.csv"):
    if not os.path.exists(xml_path): return
    tree = ET.parse(xml_path)
    root = tree.getroot()
    rtm_data = []
    for test in root.findall('.//test'):
        test_name = test.get('name', 'Unknown')
        status = test.find('status').get('status', 'FAIL') if test.find('status') is not None else 'FAIL'
        brd_id, compliance = "N/A", "N/A"
        for tag in test.findall('.//tag'):
            if tag.text.startswith("REQ:BRD-"): brd_id = tag.text
            elif tag.text.startswith("Compliance-"): compliance = tag.text
        rtm_data.append({"BRD_ID": brd_id, "Test_Name": test_name, "Compliance": compliance, "Status": status})
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, mode='w', newline='') as file:
        writer = csv.DictWriter(file, fieldnames=["BRD_ID", "Test_Name", "Compliance", "Status"])
        writer.writeheader()
        writer.writerows(rtm_data)
    print(f"[UNICODE:2705] Live RTM Matrix generated successfully at {out_path}")
if __name__ == "__main__": generate_rtm_matrix()
