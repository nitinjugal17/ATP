package com.enterprise.qa.automation;

import org.junit.jupiter.api.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.time.Duration;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Enterprise Production-Grade Selenium + JUnit 5 Test Suite
 * Target SUT: https://zerodha.com
 * Generated for full regression and ASPICE Level 3 compliance
 */
public class AutoUITest {

    private static WebDriver driver;
    private static final String TARGET_URL = "https://zerodha.com";
    private static WebDriverWait wait;

    @BeforeAll
    public static void setUpClass() {
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--headless=new");
        options.addArguments("--no-sandbox");
        options.addArguments("--disable-dev-shm-usage");
        options.addArguments("--window-size=1920,1080");
        options.addArguments("user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36");

        driver = new ChromeDriver(options);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    @AfterAll
    public static void tearDownClass() {
        if (driver != null) {
            driver.quit();
        }
    }

    @BeforeEach
    public void navigateToTarget() {
        driver.get(TARGET_URL);
        wait.until(d -> ((JavascriptExecutor) d).executeScript("return document.readyState").equals("complete"));
    }

    @Test
    @DisplayName("TC-JAVA-01: Verify Reachability, Valid HTTP URL and Legitimate Page Title")
    public void testReachabilityAndTitle() {
        String currentUrl = driver.getCurrentUrl();
        assertNotNull(currentUrl, "Current URL must not be null");
        assertTrue(currentUrl.startsWith("http"), "URL must use valid HTTP/HTTPS protocol");

        String title = driver.getTitle();
        assertNotNull(title, "Title must not be null");
        assertFalse(title.trim().isEmpty(), "Page title must not be empty");

        String[] antiBotMarkers = {"just a moment", "security verification", "attention required", "verify you are human", "cloudflare", "turnstile"};
        for (String marker : antiBotMarkers) {
            assertFalse(title.toLowerCase().contains(marker), 
                "Page title indicates an active anti-bot barrier: " + title);
        }
    }

    @Test
    @DisplayName("TC-JAVA-02: Verify Layout Architecture & Structural Section Containers")
    public void testStructuralSections() {
        List<WebElement> sections = driver.findElements(By.cssSelector("header, nav, main, footer, section, article, div[class*='container']"));
        assertFalse(sections.isEmpty(), "Document must render at least one structural container");
        assertTrue(sections.get(0).isDisplayed(), "Primary layout container must be visible");
    }

    @Test
    @DisplayName("TC-JAVA-03: Verify Semantic Headings Hierarchy Presence")
    public void testHeadingsHierarchy() {
        List<WebElement> headings = driver.findElements(By.cssSelector("h1, h2, h3"));
        assertFalse(headings.isEmpty(), "Page must contain semantic headings");
        String topText = headings.get(0).getText().trim();
        assertFalse(topText.isEmpty(), "Primary heading text must not be empty");
    }

    @Test
    @DisplayName("TC-JAVA-04: Verify Interactive Action Elements State")
    public void testInteractiveActions() {
        List<WebElement> buttons = driver.findElements(By.cssSelector("button, a.btn, [role='button'], input[type='submit']"));
        if (!buttons.isEmpty()) {
            WebElement first = buttons.get(0);
            assertNotNull(first, "Button element exists");
            assertTrue(first.isEnabled(), "Action button should be enabled for interaction");
        } else {
            List<WebElement> links = driver.findElements(By.tagName("a"));
            assertFalse(links.isEmpty(), "Page must render navigation links if no buttons present");
        }
    }

    @Test
    @DisplayName("TC-JAVA-05: Verify Client-Side Navigation Stability")
    public void testClientNavigationStability() {
        String source = driver.getPageSource();
        assertNotNull(source, "DOM source must be non-null");
        assertTrue(source.length() > 200, "DOM source length must be substantial");
        assertFalse(source.toLowerCase().contains("500 internal server error"), "Page must not throw 500 error");
    }
}
