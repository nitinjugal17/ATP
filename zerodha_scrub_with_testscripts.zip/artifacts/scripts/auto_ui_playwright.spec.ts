import { test, expect, Page } from '@playwright/test';

/**
 * Enterprise Production-Grade Playwright POM Suite
 * SUT: https://zerodha.com
 * Architecture: Automated Page Object Model with Strict Functional Assertions
 */

export class LandingPagePOM {
    readonly page: Page;
    readonly url: string = 'https://zerodha.com/';

    constructor(page: Page) {
        this.page = page;
    }

    async navigate() {
        await this.page.goto(this.url, { waitUntil: 'domcontentloaded', timeout: 30000 });
        await this.page.waitForLoadState('networkidle').catch(() => {});
    }

    async getTitle(): Promise<string> {
        return await this.page.title();
    }

    async getHeadings(): Promise<string[]> {
        return await this.page.locator('h1, h2, h3').allInnerTexts();
    }

    async getVisibleButtons() {
        return this.page.locator('button:visible, a.btn:visible, [role="button"]:visible');
    }

    async getFormInputs() {
        return this.page.locator('input[type="text"]:visible, input[type="email"]:visible, textarea:visible');
    }
}

test.describe('Production Playwright E2E Suite: zerodhacom', () => {
    let pom: LandingPagePOM;

    test.beforeEach(async ({ page }) => {
        pom = new LandingPagePOM(page);
        await pom.navigate();
    });

    test('PW-01: Verify URL Reachability and Legitimate Document Title', async ({ page }) => {
        const title = await pom.getTitle();
        expect(title.trim().length).toBeGreaterThan(0);
        const antiBotMarkers = ['just a moment', 'security verification', 'attention required', 'verify you are human', 'cloudflare', 'turnstile'];
        for (const marker of antiBotMarkers) {
            expect(title.toLowerCase()).not.toContain(marker);
        }
    });

    test('PW-02: Verify Layout Structure & Primary Section Containers', async ({ page }) => {
        const sections = page.locator('header, nav, main, footer, section, article, div[class*="container"]');
        const count = await sections.count();
        expect(count).toBeGreaterThan(0);
        await expect(sections.first()).toBeVisible();
    });

    test('PW-03: Verify Semantic Headings Copy and Content Presence', async ({ page }) => {
        const headings = await pom.getHeadings();
        expect(headings.length).toBeGreaterThan(0);
        expect(headings[0].trim().length).toBeGreaterThan(0);
    });

    test('PW-04: Verify Interactive Buttons & Action CTA Resilience', async ({ page }) => {
        const buttons = await pom.getVisibleButtons();
        const count = await buttons.count();
        if (count > 0) {
            const firstBtn = buttons.first();
            await expect(firstBtn).toBeEnabled();
            await firstBtn.hover();
        } else {
            const links = page.locator('a[href]:visible');
            expect(await links.count()).toBeGreaterThan(0);
        }
    });

    test('PW-05: Verify Data Input Handling & Nominal Persistence', async ({ page }) => {
        const inputs = await pom.getFormInputs();
        if (await inputs.count() > 0) {
            const inp = inputs.first();
            await inp.fill('SDET-Enterprise-Test');
            await expect(inp).toHaveValue('SDET-Enterprise-Test');
        } else {
            const body = page.locator('body');
            await expect(body).toBeVisible();
        }
    });

    test('PW-06: Verify Boundary Resilience against Whitespace Input', async ({ page }) => {
        const inputs = await pom.getFormInputs();
        if (await inputs.count() > 0) {
            const inp = inputs.first();
            await inp.fill('   ');
            const pageText = await page.innerText('body');
            expect(pageText.toLowerCase()).not.toContain('500 internal server error');
        } else {
            expect(await page.title()).not.toBe('');
        }
    });

    test('PW-07: Verify Defensive Injection Resistance (OWASP XSS & SQLi)', async ({ page }) => {
        const inputs = await pom.getFormInputs();
        if (await inputs.count() > 0) {
            const inp = inputs.first();
            await inp.fill("' OR '1'='1' -- <script>alert(1)</script>");
            const source = (await page.content()).toLowerCase();
            expect(source).not.toContain('sql syntax');
            expect(source).not.toContain('uncaught exception');
        }
    });

    test('PW-08: Verify Client-Side Render Performance SLA (< 5.0s)', async ({ page }) => {
        const timing = await page.evaluate(() => {
            const perf = window.performance.timing;
            return (perf.loadEventEnd - perf.navigationStart) / 1000;
        });
        if (timing > 0) {
            expect(timing).toBeLessThanOrEqual(5.0);
        }
    });

    test('PW-09: Verify Viewport Responsiveness across Mobile & Tablet', async ({ page }) => {
        await page.setViewportSize({ width: 375, height: 667 });
        await page.waitForTimeout(300);
        await expect(page.locator('body')).toBeVisible();

        await page.setViewportSize({ width: 768, height: 1024 });
        await page.waitForTimeout(300);
        await expect(page.locator('body')).toBeVisible();

        await page.setViewportSize({ width: 1920, height: 1080 });
        await page.waitForTimeout(300);
        await expect(page.locator('body')).toBeVisible();
    });

    test('PW-10: Verify Navigation & Absence of Unhandled Console Errors', async ({ page }) => {
        const errors: string[] = [];
        page.on('pageerror', err => errors.push(err.message));
        await page.reload({ waitUntil: 'domcontentloaded' });
        expect(errors.filter(e => e.includes('Fatal') || e.includes('Crash'))).toHaveLength(0);
    });
});
