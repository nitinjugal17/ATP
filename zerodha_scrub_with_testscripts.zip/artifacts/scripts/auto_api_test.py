import unittest
import requests
import time
import urllib.parse
import os

class TestEnterpriseAPISuite(unittest.TestCase):
    """
    Enterprise REST API & Boundary Value Analysis (BVA) Test Suite.
    Exhaustively tests discovered exposed backend API routes.
    """
    @classmethod
    def setUpClass(cls):
        cls.base_url = "https://zerodha.com"
        cls.session = requests.Session()
        cls.session.headers.update({
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "Accept": "application/json, text/html, */*"
        })

    def test_01_contract_and_latency_root(self):
        """
        [ASPICE Trace: REQ-API-CONTRACT-001 | Category: HTTP_CONTRACT]
        Business Objective: Verify contract reachability, HTTP status code compliance,
        and latency SLA for GET /.
        Description: Root Application HTTP Reachability & Security Header Contract
        """
        t0 = time.time()
        try:
            if "GET" == "POST":
                res = self.session.post("https://zerodha.com/", json={"test_probe": "sdet_validation"}, timeout=10)
            else:
                res = self.session.get("https://zerodha.com/", timeout=10)
            elapsed_ms = round((time.time() - t0) * 1000, 2)
            self.assertIn(
                res.status_code, 
                [200, 201, 202, 204, 301, 302, 400, 401, 403, 404, 405, 422], 
                f"[API CONTRACT FAIL] Endpoint https://zerodha.com/ returned unexpected status HTTP {res.status_code}. Body: {res.text[:200]}"
            )
            self.assertLess(
                elapsed_ms, 
                4000, 
                f"[SLA VIOLATION] Endpoint https://zerodha.com/ took {elapsed_ms}ms (exceeded 4000ms SLA threshold)"
            )
        except requests.exceptions.RequestException as e:
            self.skipTest(f"Endpoint https://zerodha.com/ not reachable: {e}")

    def test_01_bva_boundary_validation_root(self):
        """
        [ASPICE Trace: REQ-API-BVA-001 | Boundary Value Analysis]
        Business Objective: Validate server resilience against edge-case inputs (empty body, whitespace).
        Asserts that the backend handles boundary inputs gracefully without throwing HTTP 500 crashes.
        """
        try:
            res = self.session.post("https://zerodha.com/", json={"query": "   ", "limit": 0}, timeout=8)
            self.assertNotEqual(
                res.status_code, 
                500, 
                f"[CRITICAL BVA FAILURE] Submitting boundary payload to https://zerodha.com/ caused an unhandled HTTP 500 error."
            )
        except requests.exceptions.RequestException:
            pass

    def test_01_security_injection_probe_root(self):
        """
        [ASPICE Trace: REQ-API-SEC-001 | Compliance: OWASP API Security]
        Business Objective: Probe / with SQL injection fragments and XSS payloads.
        Asserts that backend sanitizes inputs and does not leak raw database syntax errors or stack traces.
        """
        probes = ["' OR '1'='1' --", "<script>alert(1)</script>"]
        for p in probes:
            try:
                res = self.session.get(f"https://zerodha.com/?q={urllib.parse.quote(p)}", timeout=8)
                body = res.text.lower()
                self.assertNotIn("you have an error in your sql syntax", body, f"[SECURITY VULNERABILITY] SQL syntax error leaked by https://zerodha.com/")
                self.assertNotIn("fatal error: uncaught", body, f"[SECURITY VULNERABILITY] Uncaught runtime stack trace leaked by https://zerodha.com/")
            except requests.exceptions.RequestException:
                pass


    def test_02_contract_and_latency_robots_txt(self):
        """
        [ASPICE Trace: REQ-API-CONTRACT-002 | Category: POLICY]
        Business Objective: Verify contract reachability, HTTP status code compliance,
        and latency SLA for GET /robots.txt.
        Description: Standard Crawler Policy Document Check
        """
        t0 = time.time()
        try:
            if "GET" == "POST":
                res = self.session.post("https://zerodha.com/robots.txt", json={"test_probe": "sdet_validation"}, timeout=10)
            else:
                res = self.session.get("https://zerodha.com/robots.txt", timeout=10)
            elapsed_ms = round((time.time() - t0) * 1000, 2)
            self.assertIn(
                res.status_code, 
                [200, 201, 202, 204, 301, 302, 400, 401, 403, 404, 405, 422], 
                f"[API CONTRACT FAIL] Endpoint https://zerodha.com/robots.txt returned unexpected status HTTP {res.status_code}. Body: {res.text[:200]}"
            )
            self.assertLess(
                elapsed_ms, 
                4000, 
                f"[SLA VIOLATION] Endpoint https://zerodha.com/robots.txt took {elapsed_ms}ms (exceeded 4000ms SLA threshold)"
            )
        except requests.exceptions.RequestException as e:
            self.skipTest(f"Endpoint https://zerodha.com/robots.txt not reachable: {e}")

    def test_02_bva_boundary_validation_robots_txt(self):
        """
        [ASPICE Trace: REQ-API-BVA-002 | Boundary Value Analysis]
        Business Objective: Validate server resilience against edge-case inputs (empty body, whitespace).
        Asserts that the backend handles boundary inputs gracefully without throwing HTTP 500 crashes.
        """
        try:
            res = self.session.post("https://zerodha.com/robots.txt", json={"query": "   ", "limit": 0}, timeout=8)
            self.assertNotEqual(
                res.status_code, 
                500, 
                f"[CRITICAL BVA FAILURE] Submitting boundary payload to https://zerodha.com/robots.txt caused an unhandled HTTP 500 error."
            )
        except requests.exceptions.RequestException:
            pass

    def test_02_security_injection_probe_robots_txt(self):
        """
        [ASPICE Trace: REQ-API-SEC-002 | Compliance: OWASP API Security]
        Business Objective: Probe /robots.txt with SQL injection fragments and XSS payloads.
        Asserts that backend sanitizes inputs and does not leak raw database syntax errors or stack traces.
        """
        probes = ["' OR '1'='1' --", "<script>alert(1)</script>"]
        for p in probes:
            try:
                res = self.session.get(f"https://zerodha.com/robots.txt?q={urllib.parse.quote(p)}", timeout=8)
                body = res.text.lower()
                self.assertNotIn("you have an error in your sql syntax", body, f"[SECURITY VULNERABILITY] SQL syntax error leaked by https://zerodha.com/robots.txt")
                self.assertNotIn("fatal error: uncaught", body, f"[SECURITY VULNERABILITY] Uncaught runtime stack trace leaked by https://zerodha.com/robots.txt")
            except requests.exceptions.RequestException:
                pass


    def test_03_contract_and_latency_sitemap_xml(self):
        """
        [ASPICE Trace: REQ-API-CONTRACT-003 | Category: SEO_CONTRACT]
        Business Objective: Verify contract reachability, HTTP status code compliance,
        and latency SLA for GET /sitemap.xml.
        Description: Application Sitemap XML Resource Contract
        """
        t0 = time.time()
        try:
            if "GET" == "POST":
                res = self.session.post("https://zerodha.com/sitemap.xml", json={"test_probe": "sdet_validation"}, timeout=10)
            else:
                res = self.session.get("https://zerodha.com/sitemap.xml", timeout=10)
            elapsed_ms = round((time.time() - t0) * 1000, 2)
            self.assertIn(
                res.status_code, 
                [200, 201, 202, 204, 301, 302, 400, 401, 403, 404, 405, 422], 
                f"[API CONTRACT FAIL] Endpoint https://zerodha.com/sitemap.xml returned unexpected status HTTP {res.status_code}. Body: {res.text[:200]}"
            )
            self.assertLess(
                elapsed_ms, 
                4000, 
                f"[SLA VIOLATION] Endpoint https://zerodha.com/sitemap.xml took {elapsed_ms}ms (exceeded 4000ms SLA threshold)"
            )
        except requests.exceptions.RequestException as e:
            self.skipTest(f"Endpoint https://zerodha.com/sitemap.xml not reachable: {e}")

    def test_03_bva_boundary_validation_sitemap_xml(self):
        """
        [ASPICE Trace: REQ-API-BVA-003 | Boundary Value Analysis]
        Business Objective: Validate server resilience against edge-case inputs (empty body, whitespace).
        Asserts that the backend handles boundary inputs gracefully without throwing HTTP 500 crashes.
        """
        try:
            res = self.session.post("https://zerodha.com/sitemap.xml", json={"query": "   ", "limit": 0}, timeout=8)
            self.assertNotEqual(
                res.status_code, 
                500, 
                f"[CRITICAL BVA FAILURE] Submitting boundary payload to https://zerodha.com/sitemap.xml caused an unhandled HTTP 500 error."
            )
        except requests.exceptions.RequestException:
            pass

    def test_03_security_injection_probe_sitemap_xml(self):
        """
        [ASPICE Trace: REQ-API-SEC-003 | Compliance: OWASP API Security]
        Business Objective: Probe /sitemap.xml with SQL injection fragments and XSS payloads.
        Asserts that backend sanitizes inputs and does not leak raw database syntax errors or stack traces.
        """
        probes = ["' OR '1'='1' --", "<script>alert(1)</script>"]
        for p in probes:
            try:
                res = self.session.get(f"https://zerodha.com/sitemap.xml?q={urllib.parse.quote(p)}", timeout=8)
                body = res.text.lower()
                self.assertNotIn("you have an error in your sql syntax", body, f"[SECURITY VULNERABILITY] SQL syntax error leaked by https://zerodha.com/sitemap.xml")
                self.assertNotIn("fatal error: uncaught", body, f"[SECURITY VULNERABILITY] Uncaught runtime stack trace leaked by https://zerodha.com/sitemap.xml")
            except requests.exceptions.RequestException:
                pass


if __name__ == '__main__':
    unittest.main(verbosity=2)
